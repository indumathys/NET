using System;
using MyTelco.UI.hrWebServiceAgent.RecruitmentSIProxy;

namespace MyTelco.UI.hrWebServiceAgent
{
	/// <summary>
	/// Summary description for RecruitmentSA.
	/// </summary>
	public class RecruitmentSA
	{

		/// <summary>
		/// constructor
		/// </summary>
		public RecruitmentSA()
		{
		}


		public string SearchOpenings(string requiredSkills, int requiredExperience)
		{
			//declaration
			RecruitmentSI recruitmentService;
			string openings;

			recruitmentService = new RecruitmentSI();
			openings = recruitmentService.SearchOpenings(requiredSkills, requiredExperience);

			return openings;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="jobCode"></param>
		/// <param name="candidateName"></param>
		/// <param name="DOB"></param>
		/// <param name="Address"></param>
		/// <param name="phone"></param>
		/// <param name="email"></param>
		/// <param name="resume"></param>
		/// <param name="source"></param>
		public void ApplyForJob(string jobCode, string candidateName, DateTime DOB, string Address, string phone, string email, object resume, string source)
		{
			//declaration
			RecruitmentSI recruitmentService;

			recruitmentService = new RecruitmentSI();
			recruitmentService.ApplyForJob(jobCode, candidateName, DOB, Address, phone, email, resume, source);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="candidateCode"></param>
		/// <returns></returns>
		public Object ViewCandidateResume(int candidateCode)
		{
			//declaration
			RecruitmentSI recruitmentService;
			Object resume;

			recruitmentService = new RecruitmentSI();
			resume = recruitmentService.ViewCandidateResume(candidateCode);
			return resume;

		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="candidateCode"></param>
		/// <param name="resume"></param>
		public void UpdateCandidateResume(int candidateCode, object resume)
		{
			//declaration
			RecruitmentSI recruitmentService;

			recruitmentService = new RecruitmentSI();
			recruitmentService.UpdateCandidateResume(candidateCode, resume);

		}	

		/// <summary>
		/// 
		/// </summary>
		/// <param name="candidateCode"></param>
		/// <param name="jobCode"></param>
		/// <param name="status"></param>
		/// <param name="source"></param>
		/// <param name="remarks"></param>
		public void UpdateCandidateStatus(int candidateCode, string jobCode,int status, string  source, string remarks)
		{
			//declaration
			RecruitmentSI recruitmentService;
			RecruitmentSIProxy.candidateStatus candStatus;
			candStatus = (RecruitmentSIProxy.candidateStatus)status;

			recruitmentService = new RecruitmentSI();
			recruitmentService.UpdateCandidateStatus(candidateCode, jobCode, candStatus, source, remarks);

		}
	}
}
