
//<script langauge="JScript">

//===============================================================================

// DisplayMessage: The purpose of this function is to close the window                  
                                        
//-------------------------------------------------------------------------------

//   Arguments     : None

//

//   Return Values : None

//===============================================================================

function CloseWindow()
{
	window.close();
}
//===============================================================================

// DisplayMessage: The purpose of this function is to diplay a message                  
                                        
//-------------------------------------------------------------------------------

//   Arguments     : message as string

//

//   Return Values : None

//===============================================================================

function DisplayMessage(message)
{
	document.write(message);
}	

