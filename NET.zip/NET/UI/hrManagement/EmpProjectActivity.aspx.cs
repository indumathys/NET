using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using MyTelco.Business.hrDTO;

namespace MyTelco.UI.hrManagement
{
	/// <summary>
	/// Summary description for EmpProjectActivity.
	/// </summary>
	public partial class EmpProjectActivity : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox txtStartDate;
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void btnGetDetails_Click(object sender, System.EventArgs e)
		{
			//controller
			UIController controller;
			controller = new UIController();

			ProjectDTO empProjActDTO;
			//get details
			empProjActDTO = controller.GetEmployeeProjectActivityDetails(txtEmpNo.Text, txtProjectNo.Text, int.Parse(txtActivityNo.Text)); 

			//populate details
			txtStartDate.Text = empProjActDTO.ProjectStartDate.ToString();
			txtEndDate.Text	= empProjActDTO.ProjectEndDate.ToString();
			txtEmpTime.Text = empProjActDTO.EmployeeTime.ToString();

		}

		protected void btnAddDetails_Click(object sender, System.EventArgs e)
		{
			try
			{
				//controller
				UIController controller;
				controller = new UIController();

				ProjectDTO empProjActDTO;
				empProjActDTO = new ProjectDTO();

				empProjActDTO.ProjectEmployee = txtEmpNo.Text;
				empProjActDTO.ProjectNo = txtProjectNo.Text;
				empProjActDTO.ActivityNo = int.Parse(txtActivityNo.Text);
				empProjActDTO.EmployeeTime = float.Parse(txtEmpTime.Text);
				empProjActDTO.ProjectStartDate = DateTime.Parse(txtStartDate.Text);
				empProjActDTO.ProjectEndDate = DateTime.Parse(txtEndDate.Text);

				//add details
				controller.AddEmployeeProjectActivityDetails(empProjActDTO);
			}
			catch(Exception ex)
			{
				DisplayMessage(ex.Message);
			}
		}

		protected void btnDeleteDetails_Click(object sender, System.EventArgs e)
		{
			//controller
			UIController controller;
			controller = new UIController();

			//delete details
			controller.DeleteEmployeeProjectActivityDetails(txtEmpNo.Text, txtProjectNo.Text, int.Parse(txtActivityNo.Text));
		}

		protected void btnUpdateDetails_Click(object sender, System.EventArgs e)
		{
		
			try
			{
				//controller
				UIController controller;
				controller = new UIController();

				ProjectDTO empProjActDTO;
				empProjActDTO = new ProjectDTO();

				empProjActDTO.ProjectEmployee = txtEmpNo.Text;
				empProjActDTO.ProjectNo = txtProjectNo.Text;
				empProjActDTO.ActivityNo = int.Parse(txtActivityNo.Text);
				empProjActDTO.EmployeeTime = float.Parse(txtEmpTime.Text);
				empProjActDTO.ProjectStartDate = DateTime.Parse(txtStartDate.Text);
				empProjActDTO.ProjectEndDate = DateTime.Parse(txtEndDate.Text);

				//add details
				controller.UpdateEmployeeProjectActivityDetails(empProjActDTO);
			}
			catch(Exception ex)
			{
				DisplayMessage(ex.Message);
			}
		}

		private void DisplayMessage(string message)
		{
			string scriptText;
			string functionName;
			functionName = "DisplayMessage('" + message + "');";
			scriptText = "<script language=JScript>" + functionName + "</script>";
			if (! this.IsStartupScriptRegistered("startUp"))
			{
				this.RegisterStartupScript("startUp", scriptText);
			}
		}
	}
}