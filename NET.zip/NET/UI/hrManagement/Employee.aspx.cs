using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using MyTelco.Business.hrDTO;

namespace MyTelco.UI.hrManagement
{
	/// <summary>
	/// Summary description for Employee.
	/// </summary>
	public partial class Employee : System.Web.UI.Page
	{
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void btnAddNewEmployee_Click(object sender, System.EventArgs e)
		{
			//create new employee
			//declare
			UIController  uiController ;
			EmployeeDTO employeeDTO;

			//make object of UIController
			uiController = new UIController();
			employeeDTO = new EmployeeDTO();

			//below code to set user control attributes
			employeeDTO.FirstName = ucEmpInfo.EmployeeFirstName;
			employeeDTO.MidName = ucEmpInfo.EmployeeMidName;
			employeeDTO.LastName = ucEmpInfo.EmployeeLastName;

			//below code to set page attributes
			employeeDTO.Salary = float.Parse(txtSalary.Text.Trim());

			//update employee details
			uiController.AddNewEmployee(employeeDTO);
		}

		/// <summary>
		///  This method gets employee details using UIController class
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnGetEmpDetails_Click(object sender, System.EventArgs e)
		{
			try
			{
				//declare
				UIController  uiController ;
				EmployeeDTO employeeDTO;

				//make object of UIController
				uiController = new UIController();

				employeeDTO = uiController.GetEmployeeDetails(txtEmpNo.Text.Trim());
		
				//code to populate employee details on the page

				//below code to set user control attributes
				ucEmpInfo.EmployeeFirstName =  employeeDTO.FirstName;
				ucEmpInfo.EmployeeMidName =  employeeDTO.MidName;
				ucEmpInfo.EmployeeLastName =  employeeDTO.LastName;

				//below code to set page attributes
				txtSalary.Text = employeeDTO.Salary.ToString();
			}
			catch(Exception ex)
			{
				DisplayMessage(ex.Message);
			}
		}

		protected void btnUpdateEmpDetails_Click(object sender, System.EventArgs e)
		{
			try
			{
				//declare
				UIController  uiController ;
				EmployeeDTO employeeDTO;

				//make object of UIController
				uiController = new UIController();
				employeeDTO = new EmployeeDTO();

				//below code to set user control attributes
				employeeDTO.FirstName = ucEmpInfo.EmployeeFirstName;
				employeeDTO.MidName = ucEmpInfo.EmployeeMidName;
				employeeDTO.LastName = ucEmpInfo.EmployeeLastName;

				//below code to set page attributes
				employeeDTO.Salary = float.Parse(txtSalary.Text.Trim());

				//update employee details
				uiController.UpdateEmployeeDetails(employeeDTO);
			}
			catch(Exception ex)
			{
				DisplayMessage(ex.Message);
			}
		
		}

		private void DisplayMessage(string message)
		{
			string scriptText;
			string functionName;
			functionName = "DisplayMessage('" + message + "');";
			scriptText = "<script language=JScript>" + functionName + "</script>";
			if (! this.IsStartupScriptRegistered("startUp"))
			{
				this.RegisterStartupScript("startUp", scriptText);
			}
		}
	}
}