using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using MyTelco.Business.hrDTO;

namespace MyTelco.UI.hrManagement
{
	/// <summary>
	/// Summary description for EmpMessage.
	/// </summary>
	public partial class EmpMessage : System.Web.UI.Page
	{

		private int messageNo;
		DataSet messageDs;
	
		protected void Page_Load(object sender, System.EventArgs e)
		{

			//code to load first message
			UIController controller;
			controller = new UIController();


			if (!IsPostBack)
			{
				messageNo = 0;
				messageDs = controller.GetMsgInTrayDetails(txtEmpNo.Text);
				Session["messageDs"] = messageDs;

			}
			else
			{
				messageDs = (DataSet)Session["messageDs"];
			}

			//load first message
			txtReceivedDate.Text	= messageDs.Tables[0].Rows[messageNo].ItemArray[1].ToString();
			txtSource.Text			= messageDs.Tables[0].Rows[messageNo].ItemArray[2].ToString();
			txtSubject.Text			= messageDs.Tables[0].Rows[messageNo].ItemArray[3].ToString();
			txtNoteText.Text		= messageDs.Tables[0].Rows[messageNo].ItemArray[4].ToString();

 		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void btnPrev_Click(object sender, System.EventArgs e)
		{
			if ( messageNo > 0 )
			{
				messageNo -= 1;
				//load prev message
				txtReceivedDate.Text	= messageDs.Tables[0].Rows[messageNo].ItemArray[1].ToString();
				txtSource.Text			= messageDs.Tables[0].Rows[messageNo].ItemArray[2].ToString();
				txtSubject.Text			= messageDs.Tables[0].Rows[messageNo].ItemArray[3].ToString();
				txtNoteText.Text		= messageDs.Tables[0].Rows[messageNo].ItemArray[4].ToString();

			}
		}

		protected void btnNext_Click(object sender, System.EventArgs e)
		{
			if ( messageNo < messageDs.Tables[0].Rows.Count - 1 )
			{
				messageNo += 1;
				//load next message
				txtReceivedDate.Text	= messageDs.Tables[0].Rows[messageNo].ItemArray[1].ToString();
				txtSource.Text			= messageDs.Tables[0].Rows[messageNo].ItemArray[2].ToString();
				txtSubject.Text			= messageDs.Tables[0].Rows[messageNo].ItemArray[3].ToString();
				txtNoteText.Text		= messageDs.Tables[0].Rows[messageNo].ItemArray[4].ToString();

			}
		}

		protected void btnDelete_Click(object sender, System.EventArgs e)
		{
			//delete message
			UIController controller;
			controller= new UIController();

			controller.DeleteMsgInTrayDetails(txtEmpNo.Text, DateTime.Parse(txtReceivedDate.Text));
		
		}

		protected void btnReply_Click(object sender, System.EventArgs e)
		{
			//declare
			UIController controller;
			controller= new UIController();

			MessageDTO messageDTO;
			messageDTO = new MessageDTO();

			messageDTO.Source = txtEmpNo.Text;
			messageDTO.NoteText = txtNoteText.Text;
			messageDTO.ReceivedTime = DateTime.Now;
			messageDTO.Subject = txtSubject.Text;
			messageDTO.EmployeeNo = "SYSTEM";

			//send the message to administrator
			controller.AddMsgInTrayDetails(messageDTO);
		
		}

		protected void btnUpdate_Click(object sender, System.EventArgs e)
		{
			try
			{
				//update changes in messages
				UIController controller;
				controller= new UIController();

				MessageDTO messageDTO;
				messageDTO = new MessageDTO();

				messageDTO.Source = txtEmpNo.Text;
				messageDTO.NoteText = txtNoteText.Text;
				messageDTO.ReceivedTime = DateTime.Now;
				messageDTO.Subject = txtSubject.Text;
				messageDTO.EmployeeNo = "SYSTEM";

				//send the message to administrator
				controller.UpdateMsgInTrayDetails(messageDTO);
			}
			catch(Exception ex)
			{
				DisplayMessage(ex.Message);
			}
		
		}
		private void DisplayMessage(string message)
		{
			string scriptText;
			string functionName;
			functionName = "DisplayMessage('" + message + "');";
			scriptText = "<script language=JScript>" + functionName + "</script>";
			if (! this.IsStartupScriptRegistered("startUp"))
			{
				this.RegisterStartupScript("startUp", scriptText);
			}
		}
	}
}
