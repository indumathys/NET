using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using MyTelco.Business.hrDTO;

namespace MyTelco.UI.hrManagement
{
	/// <summary>
	/// Summary description for Department.
	/// </summary>
	public partial class Department : System.Web.UI.Page
	{
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void btnGetDepartmentDetails_Click(object sender, System.EventArgs e)
		{

			try
			{
				//get department details and display on the page
				UIController controller;
				DepartmentDTO departmentDTO;

				controller = new UIController();

				departmentDTO = controller.GetDepartmentDetails(txtDeptNo.Text);

				//display on the page
				txtDeptName.Text	= departmentDTO.DeptName ;
				txtAdmrDept.Text	= departmentDTO.AdminDeptNo;
				txtLocation.Text	= departmentDTO.Location;
				txtMngrNo.Text		= departmentDTO.ManagerNo;
			}
			catch(Exception ex)
			{
				DisplayMessage(ex.Message);
			}

		}

		protected void btnUpdateDepartmentDetails_Click(object sender, System.EventArgs e)
		{
			try
			{
				//get department details and display on the page
				UIController controller;
				DepartmentDTO departmentDTO;

				controller = new UIController();
				departmentDTO = new DepartmentDTO();

				//display on the page
				departmentDTO.DeptName  = txtDeptName.Text;
				departmentDTO.AdminDeptNo = txtAdmrDept.Text;
				departmentDTO.Location = txtLocation.Text;
				departmentDTO.ManagerNo = txtMngrNo.Text	;

				controller.UpdateDepartmentDetails(departmentDTO);
			}
			catch(Exception ex)
			{
				DisplayMessage(ex.Message);
			}
		}

		private void DisplayMessage(string message)
		{
			string scriptText;
			string functionName;
			functionName = "DisplayMessage('" + message + "');";
			scriptText = "<script language=JScript>" + functionName + "</script>";
			if (! this.IsStartupScriptRegistered("startUp"))
			{
				this.RegisterStartupScript("startUp", scriptText);
			}
		}
	}
}
