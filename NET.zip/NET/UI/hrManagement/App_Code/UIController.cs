using System;
using System.Data;
using MyTelco.Business.hrDTO;
using MyTelco.Services.hrServiceAgent;
using MyTelco.UI.hrWebServiceAgent;

namespace MyTelco.UI.hrManagement
{
	/// <summary>
	/// Summary description for UIController.
	/// </summary>
	public class UIController
	{

		/// <summary>
		/// constructor
		/// </summary>
		public UIController()
		{
		}

		
		#region "Controller functions for Project"

		/// <summary>
		///  Method to get project details
		/// </summary>
		/// <param name="projectNo"></param>
		/// <returns></returns>
		public ProjectDTO GetProjectDetails(string projectNo)
		{
			//declare
			ProjectDTO projectDTO;
			ProjectSA projectSA;
 
			//object creation
			projectSA = new ProjectSA();

			//call method to get project details
			projectDTO = projectSA.GetProjectDetails(projectNo);

			//return details
			return projectDTO;
		}

		/// <summary>
		/// Method to update project details
		/// </summary>
		/// <param name="projectDTO"></param>
		public void UpdateProjectDetails(ProjectDTO projectDTO)
		{
			//declare
			ProjectSA projectSA;
 
			//object creation
			projectSA = new ProjectSA ();

			//call method to update details
			projectSA.UpdateProjectDetails(projectDTO);
			
		}
		
		/// <summary>
		///  Method for inserting a new project record
		/// </summary>
		/// <param name="projectDTO"></param>
		public void AddProjectDetails(ProjectDTO projectDTO)
		{
			//declare
			ProjectSA projectSA;
 
			//object creation
			projectSA = new ProjectSA();

			//call  method to update details
			projectSA.AddProjectDetails(projectDTO);
		}

		#endregion

		#region "Controller functions for Activity"

		/// <summary>
		///  This method calls method for getting activity details
		/// </summary>
		/// <param name="activityNo"></param>
		/// <returns></returns>
		public ActivityDTO GetActivityDetails(int activityNo)
		{
			//declare
			ActivitySA activitySA;
			ActivityDTO activityDTO;

			//object creation
			activitySA = new ActivitySA();

			//call method and return the DTO
			activityDTO = activitySA.GetActivityDetails(activityNo);

			return activityDTO;
		}

		/// <summary>
		/// This method calls method class for updating Activity details
		/// </summary>
		/// <param name="activityDTO"></param>
		public void UpdateActivityDetails(ActivityDTO activityDTO)
		{
			//declare
			ActivitySA activitySA;

			//object creation
			activitySA = new ActivitySA();

			//call  method 
			activitySA.UpdateActivityDetails(activityDTO);

		}

		/// <summary>
		/// This method calls method class for adding Activity details
		/// </summary>
		/// <param name="activityDTO"></param>
		public void AddActivityDetails(ActivityDTO activityDTO)
		{
			//declare
			ActivitySA activitySA;

			//object creation
			activitySA = new ActivitySA();

			//call  method 
			activitySA.AddActivityDetails(activityDTO);
		}

		/// <summary>
		/// This method calls method class for getting Project activity details
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityDTO"></param>
		public void GetPActivityDetails(ref ProjectDTO pActivityDTO, ref ActivityDTO activityDTO)
		{
			//declare
			ActivitySA activitySA;

			//object creation
			activitySA = new ActivitySA();

			//call  method 
			activitySA.GetPActivityDetails(ref pActivityDTO, ref activityDTO);
		}

		/// <summary>
		/// This method calls method class for updating Project activity details
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityNo"></param>
		public void UpdatePActivityDetails(ProjectDTO pActivityDTO, int activityNo)
		{
			//declare
			ActivitySA activitySA;

			//object creation
			activitySA = new ActivitySA();

			//call  method 
			activitySA.UpdatePActivityDetails(pActivityDTO, activityNo);
		}

		/// <summary>
		/// This method calls method class for adding Project activity details
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityNo"></param>
		public void AddPActivityDetails(ProjectDTO pActivityDTO, int activityNo)
		{
			//declare
			ActivitySA activitySA;

			//object creation
			activitySA = new ActivitySA();

			//call  method 
			activitySA.AddPActivityDetails(pActivityDTO, activityNo);
		}

		/// <summary>
		/// This method calls method class for deleting Project activity details 
		/// </summary>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
								
		public void DeletePActivityDetails(string projectNo, int activityNo)
		{
			//declare
			ActivitySA activitySA;

			//object creation
			activitySA = new ActivitySA();

			//call  method 
			activitySA.DeletePActivityDetails(projectNo, activityNo);
		}

		#endregion

		#region "Controller functions for Employee"

		/// <summary>
		/// This method calls method from service agent class
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
		/// <returns></returns>
		public ProjectDTO GetEmployeeProjectActivityDetails(string employeeNo, string projectNo, int activityNo)
		{
			//declare
			EmployeeSA employeeSA;
			ProjectDTO empProjActDTO;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			empProjActDTO = employeeSA.GetEmployeeProjectActivityDetails(employeeNo, projectNo, activityNo);

			return empProjActDTO;
		}		

		/// <summary>
		/// This method calls method from service agent class
		/// </summary>
		/// <param name="empProjActDTO"></param>
		public void UpdateEmployeeProjectActivityDetails(ProjectDTO empProjActDTO)
		{
			//declare
			EmployeeSA employeeSA;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			employeeSA.UpdateEmployeeProjectActivityDetails(empProjActDTO);

		}

		/// <summary>
		/// This method calls method from employee service agent class
		/// </summary>
		/// <param name="empProjActDTO"></param>
		public void AddEmployeeProjectActivityDetails(ProjectDTO empProjActDTO)
		{
			//declare
			EmployeeSA employeeSA;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			employeeSA.AddEmployeeProjectActivityDetails(empProjActDTO);
		}
		
		/// <summary>
		/// This method calls method from employee service agent class
		/// </summary>
		/// <param name="emplyeeNo"></param>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
		public void DeleteEmployeeProjectActivityDetails(string emplyeeNo, string projectNo, int activityNo)
		{
			//declare
			EmployeeSA employeeSA;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			employeeSA.DeleteEmployeeProjectActivityDetails(emplyeeNo, projectNo, activityNo);
		}
		
		/// <summary>
		/// This method calls method from employee service agent class
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <returns></returns>
		public DataSet GetMsgInTrayDetails(string employeeNo)
		{
			//declare
			EmployeeSA employeeSA;
			DataSet messageDetailsDs;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			messageDetailsDs = employeeSA.GetMsgInTrayDetails(employeeNo);

			return messageDetailsDs;
		}
		
		/// <summary>
		/// This method calls method from employee service agent class
		/// </summary>
		/// <param name="messageDTO"></param>
		public void UpdateMsgInTrayDetails(MessageDTO messageDTO)
		{
			//declare
			EmployeeSA employeeSA;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			employeeSA.UpdateMsgInTrayDetails(messageDTO);
		}
		
		/// <summary>
		/// This method calls method from employee service agent class
		/// </summary>
		/// <param name="messageDTO"></param>
		public void AddMsgInTrayDetails(MessageDTO messageDTO)
		{
			//declare
			EmployeeSA employeeSA;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			employeeSA.AddMsgInTrayDetails(messageDTO);
		}
		
		/// <summary>
		/// This method calls method from employee service agent class
		/// </summary>
		/// <param name="emplyeeNo"></param>
		/// <param name="received"></param>
		public void DeleteMsgInTrayDetails(string emplyeeNo, DateTime received)
		{
			//declare
			EmployeeSA employeeSA;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			employeeSA.DeleteMsgInTrayDetails(emplyeeNo, received);
		}
		
		/// <summary>
		/// This method calls method from employee service agent class
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <returns></returns>
		public EmployeeDTO GetEmployeeDetails(string employeeNo)
		{
			//declare
			EmployeeSA employeeSA;
			EmployeeDTO employeeDTO;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			employeeDTO = employeeSA.GetEmployeeDetails(employeeNo);

			return employeeDTO;
		}
		
		/// <summary>
		/// This method calls method from employee service agent class
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void UpdateEmployeeDetails(EmployeeDTO employeeDTO)
		{
			//declare
			EmployeeSA employeeSA;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			employeeSA.UpdateEmployeeDetails(employeeDTO);
		}
		
		/// <summary>
		/// This method calls method from employee service agent class
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void AddNewEmployee(EmployeeDTO employeeDTO)
		{
			//declare
			EmployeeSA employeeSA;

			//object creation
			employeeSA = new EmployeeSA();

			//call Business method
			employeeSA.AddNewEmployee(employeeDTO);
		}
		
		#endregion

		#region "Controller functions for Department"

		/// <summary>
		///  Method to get department details for a given department
		/// </summary>
		/// <param name="departmentNo"></param>
		/// <returns></returns>
		public DepartmentDTO GetDepartmentDetails(string departmentNo)
		{
			//declare
			DepartmentSA departmentSA;
			DepartmentDTO departmentDTO;

			//object creation
			departmentSA = new DepartmentSA();

			//call method
			departmentDTO = departmentSA.GetDepartmentDetails(departmentNo);

			//return DTO
			return departmentDTO;
		}


		/// <summary>
		///  Method to update department details
		/// </summary>
		/// <param name="departmentDTO"></param>
		public void UpdateDepartmentDetails(DepartmentDTO departmentDTO)
		{
			//declare
			DepartmentSA departmentSA;

			//object creation
			departmentSA = new DepartmentSA();

			//call method
			departmentSA.UpdateDepartmentDetails(departmentDTO);

		}
		
		#endregion

		#region "Controller functions for Recruitment"

		public string SearchOpenings(string requiredSkills, int requiredExperience)
		{
			//declaration
			RecruitmentSA recruitmentSA;
			string openings;

			recruitmentSA = new RecruitmentSA();
			openings = recruitmentSA.SearchOpenings(requiredSkills, requiredExperience);

			return openings;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="jobCode"></param>
		/// <param name="candidateName"></param>
		/// <param name="DOB"></param>
		/// <param name="Address"></param>
		/// <param name="phone"></param>
		/// <param name="email"></param>
		/// <param name="resume"></param>
		/// <param name="source"></param>
		public void ApplyForJob(string jobCode, string candidateName, DateTime DOB, string Address, string phone, string email, object resume, string source)
		{
			//declaration
			RecruitmentSA recruitmentSA;

			recruitmentSA = new RecruitmentSA();
			recruitmentSA.ApplyForJob(jobCode, candidateName, DOB, Address, phone, email, resume, source);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="candidateCode"></param>
		/// <returns></returns>
		public Object ViewCandidateResume(int candidateCode)
		{
			//declaration
			RecruitmentSA recruitmentSA;
			Object resume;

			recruitmentSA = new RecruitmentSA();
			resume = recruitmentSA.ViewCandidateResume(candidateCode);
			return resume;

		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="candidateCode"></param>
		/// <param name="resume"></param>
		public void UpdateCandidateResume(int candidateCode, object resume)
		{
			//declaration
			RecruitmentSA recruitmentSA;

			recruitmentSA = new RecruitmentSA();
			recruitmentSA.UpdateCandidateResume(candidateCode, resume);

		}	

		/// <summary>
		/// 
		/// </summary>
		/// <param name="candidateCode"></param>
		/// <param name="jobCode"></param>
		/// <param name="status"></param>
		/// <param name="source"></param>
		/// <param name="remarks"></param>
		public void UpdateCandidateStatus(int candidateCode, string jobCode,int status, string  source, string remarks)
		{
			//declaration
			RecruitmentSA recruitmentSA;

			recruitmentSA = new RecruitmentSA();
			recruitmentSA.UpdateCandidateStatus(candidateCode, jobCode, status, source, remarks);

		}

		#endregion
	}
}
