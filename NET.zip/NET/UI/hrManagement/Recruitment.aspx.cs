using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace MyTelco.UI.hrManagement
{
	/// <summary>
	/// Summary description for Recruitment.
	/// </summary>
	public partial class Recruitment : System.Web.UI.Page
	{
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void btnViewResume_Click(object sender, System.EventArgs e)
		{
			//controller
			UIController controller;
			controller = new UIController();
			Object resume;
		
			resume = controller.ViewCandidateResume(int.Parse(txtCandidateCode.Text));
		}

		protected void btnSearchOpenings_Click(object sender, System.EventArgs e)
		{
			//controller
			UIController controller;
			controller = new UIController();
			string results;
		
			results = controller.SearchOpenings(txtSearchWord.Text, int.Parse(txtExp.Text));

		
		}

		protected void btnApplyForJob_Click(object sender, System.EventArgs e)
		{
			//controller
			UIController controller;
			controller = new UIController();
			string jobCode = "1", candidateName = "self cooper", Address = "naive coloby, LA", Phone = "87363", Email = "self@mytelco.com", source = "0";
			DateTime DOB = DateTime.Now;

			controller.ApplyForJob(jobCode, candidateName, DOB, Address, Phone, Email, txtLatestResume, source);

		}

		protected void btnUpdateStatus_Click(object sender, System.EventArgs e)
		{
			//controller
			UIController controller;
			controller = new UIController();
			string jobCode = "1", remarks = "comments", source = "system";
			DateTime DOB = DateTime.Now;
			int status = 0;

			controller.UpdateCandidateStatus(int.Parse(txtCandidateCodeForStatus.Text),jobCode, status, source, remarks);
		}

		protected void btnUpdateResume_Click(object sender, System.EventArgs e)
		{
			//controller
			UIController controller;
			controller = new UIController();

			controller.UpdateCandidateResume(int.Parse(txtCandidateCode.Text),txtLatestResume.Text);
		
		}
	}
}