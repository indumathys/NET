using System;
using System.Data;
using MyTelco.Business.hrBO;
using MyTelco.Business.hrDTO;


namespace MyTelco.Services.hrServiceAgent
{
	/// <summary>
	/// Summary description for EmployeeSA.
	/// </summary>
	public class EmployeeSA
	{

		/// <summary>
		/// constructor
		/// </summary>
		public EmployeeSA()
		{
		}

		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
		/// <returns></returns>
		public ProjectDTO GetEmployeeProjectActivityDetails(string employeeNo, string projectNo, int activityNo)
		{
			//declare
			EmployeeBO employeeBO;
			ProjectDTO empProjActDTO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			empProjActDTO = employeeBO.GetEmployeeProjectActivityDetails(employeeNo, projectNo, activityNo);

			return empProjActDTO;
		}		

		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="empProjActDTO"></param>
		public void UpdateEmployeeProjectActivityDetails(ProjectDTO empProjActDTO)
		{
			//declare
			EmployeeBO employeeBO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			employeeBO.UpdateEmployeeProjectActivityDetails(empProjActDTO);

		}

		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="empProjActDTO"></param>
		public void AddEmployeeProjectActivityDetails(ProjectDTO empProjActDTO)
		{
			//declare
			EmployeeBO employeeBO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			employeeBO.AddEmployeeProjectActivityDetails(empProjActDTO);
		}
		
		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="emplyeeNo"></param>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
		public void DeleteEmployeeProjectActivityDetails(string emplyeeNo, string projectNo, int activityNo)
		{
			//declare
			EmployeeBO employeeBO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			employeeBO.DeleteEmployeeProjectActivityDetails(emplyeeNo, projectNo, activityNo);
		}
		
		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <returns></returns>
		public DataSet GetMsgInTrayDetails(string employeeNo)
		{
			//declare
			EmployeeBO employeeBO;
			DataSet messageDetailsDs;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			messageDetailsDs = employeeBO.GetMsgInTrayDetails(employeeNo);

			return messageDetailsDs;
		}
		
		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="messageDTO"></param>
		public void UpdateMsgInTrayDetails(MessageDTO messageDTO)
		{
			//declare
			EmployeeBO employeeBO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			employeeBO.UpdateMsgInTrayDetails(messageDTO);
		}
		
		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="messageDTO"></param>
		public void AddMsgInTrayDetails(MessageDTO messageDTO)
		{
			//declare
			EmployeeBO employeeBO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			employeeBO.AddMsgInTrayDetails(messageDTO);
		}
		
		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="emplyeeNo"></param>
		/// <param name="received"></param>
		public void DeleteMsgInTrayDetails(string emplyeeNo, DateTime received)
		{
			//declare
			EmployeeBO employeeBO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			employeeBO.DeleteMsgInTrayDetails(emplyeeNo, received);
		}
		
		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <returns></returns>
		public EmployeeDTO GetEmployeeDetails(string employeeNo)
		{
			//declare
			EmployeeBO employeeBO;
			EmployeeDTO employeeDTO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			employeeDTO = employeeBO.GetEmployeeDetails(employeeNo);

			return employeeDTO;
		}
		
		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void UpdateEmployeeDetails(EmployeeDTO employeeDTO)
		{
			//declare
			EmployeeBO employeeBO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			employeeBO.UpdateEmployeeDetails(employeeDTO);
		}
		
		/// <summary>
		/// This method calls method from employee business class
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void AddNewEmployee(EmployeeDTO employeeDTO)
		{
			//declare
			EmployeeBO employeeBO;

			//object creation
			employeeBO = new EmployeeBO();

			//call Business method
			employeeBO.AddNewEmployee(employeeDTO);
		}
	
	}
}
