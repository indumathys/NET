using System;
using MyTelco.Business.hrBO;
using MyTelco.Business.hrDTO;

namespace MyTelco.Services.hrServiceAgent
{
	/// <summary>
	/// Summary description for ActivitySA.
	/// </summary>
	public class ActivitySA
	{

		/// <summary>
		/// constructor
		/// </summary>
		public ActivitySA()
		{
		}

		/// <summary>
		///  This method calls business class for getting activity details
		/// </summary>
		/// <param name="activityNo"></param>
		/// <returns></returns>
		public ActivityDTO GetActivityDetails(int activityNo)
		{
			//declare
			ActivityBO activityBO;
			ActivityDTO activityDTO;

			//object creation
			activityBO = new ActivityBO();

			//call business method and return the DTO
			activityDTO = activityBO.GetActivityDetails(activityNo);

			return activityDTO;
		}

		/// <summary>
		/// This method calls business class for updating Activity details
		/// </summary>
		/// <param name="activityDTO"></param>
		public void UpdateActivityDetails(ActivityDTO activityDTO)
		{
			//declare
			ActivityBO activityBO;

			//object creation
			activityBO = new ActivityBO();

			//call business method 
			activityBO.UpdateActivityDetails(activityDTO);

		}

		/// <summary>
		/// This method calls business class for adding Activity details
		/// </summary>
		/// <param name="activityDTO"></param>
		public void AddActivityDetails(ActivityDTO activityDTO)
		{
			//declare
			ActivityBO activityBO;

			//object creation
			activityBO = new ActivityBO();

			//call business method 
			activityBO.AddActivityDetails(activityDTO);
		}

		/// <summary>
		/// This method calls business class for getting Project activity details
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityDTO"></param>
		public void GetPActivityDetails(ref ProjectDTO pActivityDTO, ref ActivityDTO activityDTO)
		{
			//declare
			ActivityBO activityBO;

			//object creation
			activityBO = new ActivityBO();

			//call business method 
			activityBO.GetPActivityDetails(ref pActivityDTO, ref activityDTO);
		}

		/// <summary>
		/// This method calls business class for updating Project activity details
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityNo"></param>
		public void UpdatePActivityDetails(ProjectDTO pActivityDTO, int activityNo)
		{
			//declare
			ActivityBO activityBO;

			//object creation
			activityBO = new ActivityBO();

			//call business method 
			activityBO.UpdatePActivityDetails(pActivityDTO, activityNo);
		}

		/// <summary>
		/// This method calls business class for adding Project activity details
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityNo"></param>
		public void AddPActivityDetails(ProjectDTO pActivityDTO, int activityNo)
		{
			//declare
			ActivityBO activityBO;

			//object creation
			activityBO = new ActivityBO();

			//call business method 
			activityBO.AddPActivityDetails(pActivityDTO, activityNo);
		}

		/// <summary>
		/// This method calls business class for deleting Project activity details 
		/// </summary>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
								
		public void DeletePActivityDetails(string projectNo, int activityNo)
		{
			//declare
			ActivityBO activityBO;

			//object creation
			activityBO = new ActivityBO();

			//call business method 
			activityBO.DeletePActivityDetails(projectNo, activityNo);
		}
	}
}
