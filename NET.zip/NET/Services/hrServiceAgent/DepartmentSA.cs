using System;
using MyTelco.Business.hrBO;
using MyTelco.Business.hrDTO;

namespace MyTelco.Services.hrServiceAgent
{
	/// <summary>
	/// Summary description for DepartmentSA.
	/// </summary>
	public class DepartmentSA
	{

		/// <summary>
		/// constructor
		/// </summary>
		public DepartmentSA()
		{
		}

		/// <summary>
		///  Method to get department details for a given department
		/// </summary>
		/// <param name="departmentNo"></param>
		/// <returns></returns>
		public DepartmentDTO GetDepartmentDetails(string departmentNo)
		{
			//declare
			DepartmentBO departmentBO;
			DepartmentDTO departmentDTO;

			//object creation
			departmentBO = new DepartmentBO();

			//call business method
			departmentDTO = departmentBO.GetDepartmentDetails(departmentNo);

			//return DTO
			return departmentDTO;
		}


		/// <summary>
		///  Method to update department details
		/// </summary>
		/// <param name="departmentDTO"></param>
		public void UpdateDepartmentDetails(DepartmentDTO departmentDTO)
		{
			//declare
			DepartmentBO departmentBO;

			//object creation
			departmentBO = new DepartmentBO();

			//call business method
			departmentBO.UpdateDepartmentDetails(departmentDTO);

		}
	}
}
