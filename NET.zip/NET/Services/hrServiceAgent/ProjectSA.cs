using System;
using MyTelco.Business.hrBO;
using MyTelco.Business.hrDTO;

namespace MyTelco.Services.hrServiceAgent
{
	/// <summary>
	/// Summary description for ProjectSA.
	/// </summary>
	public class ProjectSA
	{
		public ProjectSA()
		{
		}

		/// <summary>
		///  Method to get project details
		/// </summary>
		/// <param name="projectNo"></param>
		/// <returns></returns>
		public ProjectDTO GetProjectDetails(string projectNo)
		{
			//declare
			ProjectDTO projectDTO;
			ProjectBO projectBO;
 
			//object creation
			projectBO = new ProjectBO();

			//call business method to get project details
			projectDTO = projectBO.GetProjectDetails(projectNo);

			//return details
			return projectDTO;
		}

		/// <summary>
		/// Method to update project details
		/// </summary>
		/// <param name="projectDTO"></param>
		public void UpdateProjectDetails(ProjectDTO projectDTO)
		{
			//declare
			ProjectBO projectBO;
 
			//object creation
			projectBO = new ProjectBO ();

			//call method to update details
			projectBO.UpdateProjectDetails(projectDTO);
			
		}
		
		/// <summary>
		///  Method for inserting a new project record
		/// </summary>
		/// <param name="projectDTO"></param>
		public void AddProjectDetails(ProjectDTO projectDTO)
		{
			//declare
			ProjectBO projectBO;
 
			//object creation
			projectBO = new ProjectBO();

			//call business method to update details
			projectBO.AddProjectDetails(projectDTO);
		}
	}
}
