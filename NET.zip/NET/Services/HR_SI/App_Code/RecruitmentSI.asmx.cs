using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using MyTelco.Business.hrBO;

namespace MyTelco.Services.HR_SI
{
	/// <summary>
	/// Summary description for RecruitmentSI.
	/// </summary>
	public class RecruitmentSI : System.Web.Services.WebService
	{
		public RecruitmentSI()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion


		//make enum of candidate status
		public enum candidateStatus
		{
			submitted	= 0,
			InProcess	= 1,
			OnHold		= 2,
			rejected	= 3,
			selected	= 4
		};

		[WebMethod]
		public string SearchOpenings(string requiredSkills, int requiredExperience)
		{
			//declaration
			RecruitmentBO recruitBO;
			string openings;

			recruitBO = new RecruitmentBO();
			openings = recruitBO.SearchOpenings(requiredSkills, requiredExperience);

			return openings;
		}

		[WebMethod]
		public void ApplyForJob(string jobCode, string candidateName, DateTime DOB, string Address, string phone, string email, object resume, string source)
		{
			//declaration
			RecruitmentBO recruitBO;

			recruitBO = new RecruitmentBO();
			recruitBO.ApplyForJob(jobCode, candidateName, DOB, Address, phone, email, resume, source);
		}

		[WebMethod]
		public Object ViewCandidateResume(int candidateCode)
		{
			//declaration
			RecruitmentBO recruitBO;
			Object resume;

			recruitBO = new RecruitmentBO();
			resume = recruitBO.ViewCandidateResume(candidateCode);
			return resume;

		}

		[WebMethod]
		public void UpdateCandidateResume(int candidateCode, object resume)
		{
			//declaration
			RecruitmentBO recruitBO;

			recruitBO = new RecruitmentBO();
			recruitBO.UpdateCandidateResume(candidateCode, resume);

		}	

		[WebMethod]
		public void UpdateCandidateStatus(int candidateCode, string jobCode,candidateStatus status, string  source, string remarks)
		{
			//declaration
			RecruitmentBO recruitBO;

			recruitBO = new RecruitmentBO();
			recruitBO.UpdateCandidateStatus(candidateCode, jobCode, (int)status, source, remarks);

		}
	}
}
