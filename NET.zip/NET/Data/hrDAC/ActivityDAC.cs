using System;
using System.Data;
using System.Data.OracleClient;
using MyTelco.Business.hrDTO;

namespace MyTelco.Data.hrDAC
{
	/// <summary>
	/// Summary description for ActivityDAC.
	/// </summary>
	public class ActivityDAC:BaseDAC
	{
		/// <summary>
		/// constructor
		/// </summary>
		public ActivityDAC()
		{
		}

		/// <summary>
		/// This method gets activity details and populates activity dto
		/// with the activity details.
		/// This method does not use parameters
		/// </summary>
		/// <param name="activityNo"></param>
		/// <returns></returns>
		public ActivityDTO GetActivityDetails(int activityNo)
		{
			ActivityDTO activityDTO;
			string getActivityDetailsQuery;
			OracleDataReader orclDR;

			//write embedded query
			getActivityDetailsQuery = "SELECT ACT_NO, ACT_DESC, ACT_KEYWORD FROM ACTIVITY WHERE ACT_NO = {0}";

			//prepare query by replacing the activity number
			getActivityDetailsQuery = string.Format(getActivityDetailsQuery, activityNo.ToString());

			//get activity details
			orclDR = OracleHelper.ExecuteReader(GetOrclDBConnString, 
				CommandType.Text, 
				getActivityDetailsQuery);

			//read data from oracle reader
			if (orclDR.Read())
			{
				//make new projectDTO and populate
				activityDTO = new ActivityDTO();

				activityDTO.ActivityNo			= orclDR.GetInt32(orclDR.GetOrdinal("ACT_NO"));
				activityDTO.ActivityKeyword		= orclDR.GetString(orclDR.GetOrdinal("ACT_DESC"));
				activityDTO.ActivityDescription = orclDR.GetString(orclDR.GetOrdinal("ACT_KEYWORD"));

			}
			else
			{
				activityDTO = null;
			}
			return activityDTO;
		}

		/// <summary>
		///  This method Updates activity details given project DTO
		/// </summary>
		/// <param name="activityDTO"></param>
		/// <returns></returns>
		public void UpdateActivityDetails(ActivityDTO activityDTO)
		{
			//declaration
			string[] activityValues;
			string updateActivityDetailsQuery;

			activityValues = new string[2];

			activityValues[0] = activityDTO.ActivityNo.ToString();
			//NOTE: activity keyword can just be inserted and can 
			//not be updated according to business
			//activityValues[1] = activityDTO.ActivityKeyword;
			activityValues[2] = activityDTO.ActivityDescription;

			//write embedded query
			updateActivityDetailsQuery = "UPDATE ACTIVITY SET ACT_DESC = {2}  WHERE ACT_NO = {0}";

			//format the query to replace place holders with their values
			updateActivityDetailsQuery = string.Format(updateActivityDetailsQuery, activityValues);

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				updateActivityDetailsQuery);


		}

		/// <summary>
		///  This method inserts new activity details
		/// </summary>
		/// <param name="activityDTO"></param>
		/// <returns></returns>
		public void AddActivityDetails(ActivityDTO activityDTO)
		{
			//declaration
			string[] activityValues;
			string insertActivityDetailsQuery;


			activityValues = new string[2];

			activityValues[0] = activityDTO.ActivityNo.ToString();
			activityValues[1] = activityDTO.ActivityKeyword;
			activityValues[2] = activityDTO.ActivityDescription;

			//read query from configuration file
			insertActivityDetailsQuery = "INSERT INTO ACTIVITY ( ACT_NO, ACT_KEYWORD, ACT_DESC ) VALUES ({0},{1}, {2})";

			//format the query to replace place holders with their values
			insertActivityDetailsQuery = string.Format(insertActivityDetailsQuery, activityValues);

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				insertActivityDetailsQuery);

		}

		//*************************************//
		// *** queries for PActivity table *** //
		//*************************************//

		public void GetPActivityDetails(ref ProjectDTO pActivityDTO, ref ActivityDTO activityDTO)
		{
			string getPActivityDetailsQuery;
			OracleDataReader orclDR;

			//write embedded query
			getPActivityDetailsQuery = "SELECT ACT_STAFF, ACT_STARTDATE, ACT_ENDDATE FROM PACTIVITY WHERE ACT_NO = {0} AND PROJ_NO = {1}";

			//prepare query by replacing the activity number and project number
			getPActivityDetailsQuery = string.Format(getPActivityDetailsQuery, activityDTO.ActivityNo.ToString(), pActivityDTO.ProjectNo);

			//get activity details
			orclDR = OracleHelper.ExecuteReader(GetOrclDBConnString, 
				CommandType.Text, 
				getPActivityDetailsQuery);

			//read data from oracle reader
			if (orclDR.Read())
			{
				//populate projectDTO and activityDTO

				pActivityDTO.ProjectStaff		= orclDR.GetFloat(orclDR.GetOrdinal("ACT_STAFF"));
				pActivityDTO.ProjectStartDate	= orclDR.GetDateTime(orclDR.GetOrdinal("ACT_STARTDATE"));
				pActivityDTO.ProjectEndDate		= orclDR.GetDateTime(orclDR.GetOrdinal("ACT_ENDDATE"));

			}
		}

		/// <summary>
		/// updates Pactivity table for a given project number and activity number
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityNo"></param>
		public void UpdatePActivityDetails(ProjectDTO pActivityDTO, int activityNo)
		{
			//declaration
			string[] pActivityValues;
			string updatePActivityDetailsQuery;

			pActivityValues = new string[2];

			pActivityValues[0] = activityNo.ToString();
			pActivityValues[1] = pActivityDTO.ProjectNo;
			pActivityValues[2] = pActivityDTO.ProjectStaff.ToString();
			pActivityValues[2] = pActivityDTO.ProjectStartDate.ToString();
			pActivityValues[2] = pActivityDTO.ProjectEndDate.ToString();

			//write embedded query
			updatePActivityDetailsQuery = "UPDATE PACTIVITY SET ACT_STAFF = {2}, ACT_STARTDATE = {3}, ACT_ENDDATE = {4}  WHERE ACT_NO = {0} AND  PROJ_NO = {1}";

			//format the query to replace place holders with their values
			updatePActivityDetailsQuery = string.Format(updatePActivityDetailsQuery, pActivityValues);

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				updatePActivityDetailsQuery);

		}

		/// <summary>
		/// Adds a new record in PActivity table 
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityNo"></param>
		public void AddPActivityDetails(ProjectDTO pActivityDTO, int activityNo)
		{
			//declaration
			string[] pActivityValues;
			string addPActivityDetailsQuery;

			pActivityValues = new string[2];

			pActivityValues[0] = activityNo.ToString();
			pActivityValues[1] = pActivityDTO.ProjectNo;
			pActivityValues[2] = pActivityDTO.ProjectStaff.ToString();
			pActivityValues[2] = pActivityDTO.ProjectStartDate.ToString();
			pActivityValues[2] = pActivityDTO.ProjectEndDate.ToString();

			//write embedded query
			addPActivityDetailsQuery = "INSERT INTO PACTIVITY ( ACT_NO, PROJ_NO, ACT_STAFF, ACT_STARTDATE, ACT_ENDDATE ) VALUES ( {0}, {1}, {2},  TO_Date( {3}, 'MM/DD/YYYY HH:MI:SS AM'),  TO_Date( {4}, 'MM/DD/YYYY HH:MI:SS AM'))";

			//format the query to replace place holders with their values
			addPActivityDetailsQuery = string.Format(addPActivityDetailsQuery, pActivityValues);

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				addPActivityDetailsQuery);

		}

		/// <summary>
		/// removes a record from PActivity table 
		/// </summary>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
		public void DeletePActivityDetails(string projectNo, int activityNo)
		{
			//declaration
			string deletePActivityDetailsQuery;

			//write embedded query
			deletePActivityDetailsQuery = "DELETE FROM PACTIVITY WHERE ACT_NO = {0} AND PROJ_NO = {1}";

			//format the query to replace place holders with their values
			deletePActivityDetailsQuery = string.Format(deletePActivityDetailsQuery, activityNo.ToString(), projectNo);

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				deletePActivityDetailsQuery);

		}
	}
}
