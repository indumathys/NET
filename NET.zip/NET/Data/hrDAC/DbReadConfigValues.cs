using Microsoft.ApplicationBlocks.ConfigurationManagement;

namespace MyTelco.Data.hrDAC
{
	/// <summary>
	/// Summary description for DbReadConfigValues.
	/// </summary>
	public class DbReadConfigValues
	{
		public static DbConfigurationData orclDbConfig = (DbConfigurationData)ConfigurationManager.Read("Db");
		public static DbConfigurationData sqlDbConfig = (DbConfigurationData)ConfigurationManager.Read("Db");
	}
}