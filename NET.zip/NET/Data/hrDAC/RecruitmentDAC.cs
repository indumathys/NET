using System;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace MyTelco.Data.hrDAC
{
	/// <summary>
	/// Summary description for RecruitmentDAC.
	/// </summary>
	public class RecruitmentDAC : BaseDAC
	{

		//make enum of candidate status
		enum candidateStatus
		{
			submitted	= 0,
			InProcess	= 1,
			OnHold		= 2,
			rejected	= 3,
			selected	= 4
		};

		/// <summary>
		/// constructor
		/// </summary>
		public RecruitmentDAC()
		{
		}

		/// <summary>
		///  This method returns available openinings 
		///  based on the search criteria sent by the user
		///  
		///  The method uses xml reader which is supported by 
		///  ADO.net for SQL server (SQL Client) but not by  
		///  microsoft provided ADO.NET for Oracle server(OracleClient). 
		///  Later on, the xml support was provided by new Oracle client 
		///  called ODP.NET provided by oracle itself. This 
		///  component gets integrated with visual sutdio .net 
		///  and provides greater functionality although limits 
		///  a little in ease of use as compared to OracleClient 
		///  provided by microsoft.
		///  
		/// </summary>
		/// <param name="requiredSkills"></param>
		/// <param name="requiredExperience"></param>
		/// <returns></returns>
		public string SearchOpenings(string requiredSkills, int requiredExperience)
		{
			
			//declarations
			string getCurrentOpeningsQuery;
			SqlParameter[] param;
			XmlReader currentOpeningsXmlReader;
			string currentOpeningXmlString;
			SqlConnection recruitDBconnection;

			//read query from configuration file.
			getCurrentOpeningsQuery = "SELECT JobCode, DateSubmitted, Role, "
										+ "Skills, SubSkills, MinExperience, " 
										+	"MaxExperience, Location, Positions "
										+ "FROM Current_Openings "
										+ "WHERE (MinExperience < ?) AND (Skills LIKE '?')";

			//add parameters
			param = new SqlParameter[2];

			param[0]			= new SqlParameter("reqSkills", DbType.String);
			param[0].Direction	= ParameterDirection.Input;
			param[0].Value		= requiredSkills;

			param[1]			= new SqlParameter("reqExp", DbType.Int32);
			param[1].Direction	= ParameterDirection.Input;
			param[1].Value		= requiredExperience;

			//open sql connection
			recruitDBconnection = OpenSQLConnection(GetSQLDBConnString);

			//get xml reader containing job details
			currentOpeningsXmlReader = SqlHelper.ExecuteXmlReader(recruitDBconnection, 
				CommandType.Text, 
				getCurrentOpeningsQuery, 
				param);

			//read xml data
			currentOpeningXmlString = currentOpeningsXmlReader.ReadOuterXml();
			currentOpeningsXmlReader.Close();
			CloseSQLConnection(recruitDBconnection);
			return currentOpeningXmlString;
		}

		public void ApplyForJob(string jobCode, string candidateName, DateTime DOB, string Address, string phone, string email, object resume, string source)
		{
			//declarations
  			SqlParameter[] candidateDetailsParam;
			SqlConnection recruitDBconnection;
			int candidateNumber;

			//open sql connection
			recruitDBconnection = OpenSQLConnection(GetSQLDBConnString);

			candidateDetailsParam = new SqlParameter[5];

			//update candidate details table
			string insertCandidateDetailsQuery = "Insert INTO Candidate_Details " 
				+ "SET Name =?, DOB =?, Address =?, PrimaryPhone =?, Email =?";

			candidateDetailsParam[0] = new SqlParameter("candidateName", DbType.String);
			candidateDetailsParam[0].Direction = ParameterDirection.Input;
			candidateDetailsParam[0].Value = candidateName;

			candidateDetailsParam[1] = new SqlParameter("DOB", DbType.Date);
			candidateDetailsParam[1].Direction = ParameterDirection.Input;
			candidateDetailsParam[1].Value = candidateName;

			candidateDetailsParam[2] = new SqlParameter("Address", DbType.String);
			candidateDetailsParam[2].Direction = ParameterDirection.Input;
			candidateDetailsParam[2].Value = candidateName;

			candidateDetailsParam[3] = new SqlParameter("PrimaryPhone", DbType.String);
			candidateDetailsParam[3].Direction = ParameterDirection.Input;
			candidateDetailsParam[3].Value = candidateName;

			candidateDetailsParam[4] = new SqlParameter("Email", DbType.String);
			candidateDetailsParam[4].Direction = ParameterDirection.Input;
			candidateDetailsParam[4].Value = candidateName;

			//fire query
			candidateNumber = SqlHelper.ExecuteNonQuery(recruitDBconnection, CommandType.Text, insertCandidateDetailsQuery, candidateDetailsParam);

			//candidate resume
			//
			string insertCandidateResumeQuery = "Insert INTO Candidate_Resume " 
				+ "SET candidateCode =?, resume =?";

			//update candidate resume
			candidateDetailsParam = new SqlParameter[2];

			candidateDetailsParam[0] = new SqlParameter("candidateNumber", DbType.Int32);
			candidateDetailsParam[0].Direction = ParameterDirection.Input;
			candidateDetailsParam[0].Value = candidateNumber;

			candidateDetailsParam[1] = new SqlParameter("resume", DbType.Object);
			candidateDetailsParam[1].Direction = ParameterDirection.Input;
			candidateDetailsParam[1].Value = resume;

			//fire query
			SqlHelper.ExecuteNonQuery(recruitDBconnection, CommandType.Text, insertCandidateResumeQuery, candidateDetailsParam);

			//candidate status
			//
			string insertCandidateStatusQuery = "Insert INTO Candidate_status" 
				+ "SET candidateCode =?, jobCode =?, SubmittedDate = ?, Status = ?, LastUpdated = ?, SourceId = ?, Remarks = ?";

			//update candidate status
			candidateDetailsParam = new SqlParameter[7];

			candidateDetailsParam[0] = new SqlParameter("candidateNumber", DbType.Int32);
			candidateDetailsParam[0].Direction = ParameterDirection.Input;
			candidateDetailsParam[0].Value = candidateNumber;

			candidateDetailsParam[1] = new SqlParameter("jobCode", DbType.String);
			candidateDetailsParam[1].Direction = ParameterDirection.Input;
			candidateDetailsParam[1].Value = jobCode;

			candidateDetailsParam[2] = new SqlParameter("submittedDate", DbType.Date);
			candidateDetailsParam[2].Direction = ParameterDirection.Input;
			candidateDetailsParam[2].Value = DateTime.Now;

			candidateDetailsParam[3] = new SqlParameter("status", DbType.String);
			candidateDetailsParam[3].Direction = ParameterDirection.Input;
			candidateDetailsParam[3].Value = candidateStatus.submitted;

			candidateDetailsParam[4] = new SqlParameter("lastUpdated", DbType.Date);
			candidateDetailsParam[4].Direction = ParameterDirection.Input;
			candidateDetailsParam[4].Value = DateTime.Now;

			candidateDetailsParam[5] = new SqlParameter("source", DbType.String);
			candidateDetailsParam[5].Direction = ParameterDirection.Input;
			candidateDetailsParam[5].Value = source;

			candidateDetailsParam[6] = new SqlParameter("remarks", DbType.String);
			candidateDetailsParam[6].Direction = ParameterDirection.Input;
			candidateDetailsParam[6].Value = "New Resume uploaded in the systsem";

			//fire query
			SqlHelper.ExecuteNonQuery(recruitDBconnection, CommandType.Text, insertCandidateStatusQuery, candidateDetailsParam);

			CloseSQLConnection(recruitDBconnection);
		}

		public Object ViewCandidateResume(int candidateCode)
		{
			//declaration
			string getCandidateResumeQuery;
			Object candidateResume;
			SqlParameter[] candidateDetailsParam;

			getCandidateResumeQuery = "SELECT Resume FROM Candidate_Resume WHERE CandidateCode = ?";

			candidateDetailsParam = new SqlParameter[1];

			candidateDetailsParam[0] = new SqlParameter("candidateCode", DbType.Int32);
			candidateDetailsParam[0].Direction = ParameterDirection.Input;
			candidateDetailsParam[0].Value = candidateCode;

			///fire query to get candidate resume
			candidateResume = SqlHelper.ExecuteScalar(GetSQLDBConnString, CommandType.Text, getCandidateResumeQuery, candidateDetailsParam);
			return candidateResume;

		}

		public void UpdateCandidateResume(int candidateCode, Object resume)
		{
			//declaration
			string updateCandidateResumeQuery;
			SqlParameter[] candidateDetailsParam;

			updateCandidateResumeQuery = "UPDATE Candidate_Resume SET Resume = ? WHERE (CandidateCode = ?)";

			candidateDetailsParam = new SqlParameter[2];

			candidateDetailsParam[0] = new SqlParameter("candidateResume", DbType.Object);
			candidateDetailsParam[0].Direction = ParameterDirection.Input;
			candidateDetailsParam[0].Value = resume;

			candidateDetailsParam[1] = new SqlParameter("candidateCode", DbType.Int32);
			candidateDetailsParam[1].Direction = ParameterDirection.Input;
			candidateDetailsParam[1].Value = candidateCode;

			///fire query to get candidate resume
			SqlHelper.ExecuteNonQuery(GetSQLDBConnString, CommandType.Text, updateCandidateResumeQuery, candidateDetailsParam);

		}

		public void UpdateCandidateStatus(int candidateCode, string jobCode,int status, string  source, string remarks)
		{
			//declaration
			string updateCandidateStatusQuery;
			SqlParameter[] candidateStatusParam;

			updateCandidateStatusQuery = "UPDATE    Candidate_Status "
							+ "SET JobCode =?, SubmittedDate =?, Status =?, LastUpdated =?,  SourceId =?, Remarks =? WHERE (CandidateCode = ?)";

			//update candidate status
			candidateStatusParam = new SqlParameter[7];


			candidateStatusParam[0] = new SqlParameter("jobCode", DbType.String);
			candidateStatusParam[0].Direction = ParameterDirection.Input;
			candidateStatusParam[0].Value = jobCode;

			candidateStatusParam[1] = new SqlParameter("submittedDate", DbType.Date);
			candidateStatusParam[1].Direction = ParameterDirection.Input;
			candidateStatusParam[1].Value = DateTime.Now;

			candidateStatusParam[2] = new SqlParameter("status", DbType.String);
			candidateStatusParam[2].Direction = ParameterDirection.Input;
			candidateStatusParam[2].Value = status;

			candidateStatusParam[3] = new SqlParameter("lastUpdated", DbType.Date);
			candidateStatusParam[3].Direction = ParameterDirection.Input;
			candidateStatusParam[3].Value = DateTime.Now;

			candidateStatusParam[4] = new SqlParameter("source", DbType.String);
			candidateStatusParam[4].Direction = ParameterDirection.Input;
			candidateStatusParam[4].Value = source;

			candidateStatusParam[5] = new SqlParameter("remarks", DbType.String);
			candidateStatusParam[5].Direction = ParameterDirection.Input;
			candidateStatusParam[5].Value = remarks;

			candidateStatusParam[6] = new SqlParameter("candidateNumber", DbType.Int32);
			candidateStatusParam[6].Direction = ParameterDirection.Input;
			candidateStatusParam[6].Value = candidateCode;

			//fire query
			SqlHelper.ExecuteNonQuery(GetSQLDBConnString, CommandType.Text, updateCandidateStatusQuery, candidateStatusParam);

		}

	}
}
