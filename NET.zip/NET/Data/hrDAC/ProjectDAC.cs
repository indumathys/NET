using System;
using System.Data;
using System.Data.OracleClient;
using MyTelco.Business.hrDTO;
 
namespace MyTelco.Data.hrDAC
{
	/// <summary>
	/// Summary description for ProjectDAC.
	/// This class inherits Base DAC and implements IProjectDataProvider Interface.
	/// </summary>
	public class ProjectDAC : BaseDAC,  IProjectDataProvider
	{
		/// <summary>
		/// constructor
		/// </summary>
		public ProjectDAC()
		{
		}

		/// <summary>
		/// This method gets projects details and populated ProjectDTO 
		/// with the project details.
		/// This method does not make use of parameters
		/// </summary>
		/// <param name="projectNo"></param>
		/// <returns></returns>
		public ProjectDTO GetProjectDetails(string projectNo)
		{

			ProjectDTO projectDTO = new ProjectDTO();
			string getProjectDetailsQuery;
			OracleDataReader orclDR;

			//read query from configuration file.
			getProjectDetailsQuery = DbReadConfigValues.orclDbConfig.GetProjectDetailsQuery;

			//prepare query by replacing the project number
			getProjectDetailsQuery = string.Format(getProjectDetailsQuery, projectNo);

			//get project details
			orclDR = OracleHelper.ExecuteReader(GetOrclDBConnString, 
												CommandType.Text, 
												getProjectDetailsQuery);

			//read data from oracle reader
			if (orclDR.Read())
			{
				//make new projectDTO and populate
				projectDTO = new ProjectDTO();
				projectDTO.ProjectNo		= orclDR.GetString(orclDR.GetOrdinal("PROJ_NO"));
				projectDTO.ProjectName		= orclDR.GetString(orclDR.GetOrdinal("PROJ_NAME"));
				projectDTO.DeptNo			= orclDR.GetString(orclDR.GetOrdinal("DEPTNO"));
				projectDTO.ProjectEmployee	= orclDR.GetString(orclDR.GetOrdinal("PROJ_EMP"));
				projectDTO.ProjectStaff		= orclDR.GetFloat(orclDR.GetOrdinal("PROJ_STAFF"));
				projectDTO.ProjectStartDate = orclDR.GetDateTime(orclDR.GetOrdinal("PROJ_STARTDATE"));
				projectDTO.ProjectEndDate	= orclDR.GetDateTime(orclDR.GetOrdinal("PROJ_ENDDATE"));
				projectDTO.ControlProject	= orclDR.GetString(orclDR.GetOrdinal("CTRLPROJ"));
			}
			return projectDTO;
		}

		/// <summary>
		///  This method Updates projects details given project DTO
		/// </summary>
		/// <param name="projectDTO"></param>
		/// <returns></returns>
		public void UpdateProjectDetails(ProjectDTO projectDTO)
		{
			//declaration
			string[] projectValues;
			string updateProjectDetailsQuery;

			projectValues = new string[7];

			projectValues[0] = projectDTO.ProjectName;
			projectValues[1] = projectDTO.DeptNo;
			projectValues[2] = projectDTO.ProjectEmployee;
			projectValues[3] = projectDTO.ProjectStaff.ToString();
			projectValues[4] = projectDTO.ProjectStartDate.ToString();
			projectValues[5] = projectDTO.ProjectEndDate.ToString();
			projectValues[6] = projectDTO.ControlProject;
			projectValues[7] = projectDTO.ProjectNo;

			//read query from configuration file
			updateProjectDetailsQuery = DbReadConfigValues.orclDbConfig.UpdateProjectDetailsQuery;

			//format the query to replace place holders with their values
			updateProjectDetailsQuery = string.Format(updateProjectDetailsQuery, projectValues);

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
										 CommandType.Text,
										 updateProjectDetailsQuery);


		}

		/// <summary>
		///  This method inserts new project details
		/// </summary>
		/// <param name="projectDTO"></param>
		/// <returns></returns>
		public void AddProjectDetails(ProjectDTO projectDTO)
		{
			//declaration
			string[] projectValues;
			string insertProjectDetailsQuery;

			projectValues = new string[7];

			projectValues[0] = projectDTO.ProjectNo;
			projectValues[1] = projectDTO.ProjectName;
			projectValues[2] = projectDTO.DeptNo;
			projectValues[3] = projectDTO.ProjectEmployee;
			projectValues[4] = projectDTO.ProjectStaff.ToString();
			projectValues[5] = projectDTO.ProjectStartDate.ToString();
			projectValues[6] = projectDTO.ProjectEndDate.ToString();
			projectValues[7] = projectDTO.ControlProject;

			//read query from configuration file
			insertProjectDetailsQuery = DbReadConfigValues.orclDbConfig.InsertProjectDetailsQuery;

			//format the query to replace place holders with their values
			insertProjectDetailsQuery = string.Format(insertProjectDetailsQuery, projectValues);

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				insertProjectDetailsQuery);

		}
	}
}
