using System;
using System.Data;
using System.Data.OracleClient;
using MyTelco.Business.hrDTO;

namespace MyTelco.Data.hrDAC
{
	/// <summary>
	/// Summary description for DepartmentDAC.
	/// </summary>
	public class DepartmentDAC:BaseDAC
	{

		/// <summary>
		/// constructor
		/// </summary>
		public DepartmentDAC()
		{
		}

	
		/// <summary>
		///  method to read department details for a given department number
		/// </summary>
		/// <param name="departmentNo"></param>
		/// <returns></returns>
		public DepartmentDTO GetDepartmentDetails(string departmentNo)
		{
			DepartmentDTO deptDTO;
			string getDepartmentDetailsQuery;
			OracleDataReader orclDR;

			//write embedded query
			getDepartmentDetailsQuery = "SELECT DEPTNO, DEPTNAME, MGRNO, ADMRDEPT, LOCATION FROM DEPT WHERE DEPTNO = {0}";

			//prepare query by replacing the place holder 
			getDepartmentDetailsQuery = string.Format(getDepartmentDetailsQuery, departmentNo);

			//execute query using oracle helper
			orclDR = OracleHelper.ExecuteReader(GetOrclDBConnString, 
				CommandType.Text, 
				getDepartmentDetailsQuery);

			//read data from oracle reader
			if (orclDR.Read())
			{
				//make new DTO
				deptDTO = new DepartmentDTO();

				deptDTO.DeptNo		= orclDR.GetString(orclDR.GetOrdinal("DEPTNO"));
				deptDTO.DeptName	= orclDR.GetString(orclDR.GetOrdinal("DEPTNAME"));
				deptDTO.ManagerNo	= orclDR.GetString(orclDR.GetOrdinal("MGRNO"));
				deptDTO.AdminDeptNo = orclDR.GetString(orclDR.GetOrdinal("ADMRDEPT"));
				deptDTO.Location	= orclDR.GetString(orclDR.GetOrdinal("LOCATION"));
			}
			else
			{
				deptDTO = null;
			}
			return deptDTO;
		}


		/// <summary>
		///  Method to update department details
		/// </summary>
		/// <param name="departmentDTO"></param>
		public void UpdateDepartmentDetails(DepartmentDTO departmentDTO)
		{
			//declaration
			string[] deptValues;
			string updateDeptDetailsQuery;

			deptValues = new string[4];

			deptValues[0] = departmentDTO.DeptNo;
			deptValues[1] = departmentDTO.DeptName;
			deptValues[2] = departmentDTO.ManagerNo;
			deptValues[3] = departmentDTO.AdminDeptNo;
			deptValues[4] = departmentDTO.Location;

			//write embedded query
			updateDeptDetailsQuery = "UPDATE DEPT SET DEPTNAME = {1}, MGRNO = {2}, ADMRDEPT = {3}, LOCATION = {4} WHERE DEPTNO = {0}";

			//format the query to replace place holders with their values
			updateDeptDetailsQuery = string.Format(updateDeptDetailsQuery, deptValues);

			//call oracle helper to update database
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				updateDeptDetailsQuery);
		}
	}
}
