using System;
using System.Data;
using System.Data.OracleClient;
using MyTelco.Business.hrDTO;

namespace MyTelco.Data.hrDAC
{
	/// <summary>
	/// Summary description for EmployeeDAC.
	/// </summary>
	public class EmployeeDAC:BaseDAC
	{
		/// <summary>
		/// constructor
		/// </summary>
		public EmployeeDAC()
		{
		}

		#region "Queries for EMP_PROJ_ACT table"

		/// <summary>
		///  method to get employee project details
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
		/// <returns></returns>
		public ProjectDTO GetEmployeeProjectActivityDetails(string employeeNo, string projectNo, int activityNo)
		{

			//declaration
			ProjectDTO empProjActDTO;
			string getEmpProjActDetailsQuery;
			OracleDataReader orclDR;

			//write embedded query
			getEmpProjActDetailsQuery = "SELECT EMPNO, PROJ_NO, ACT_NO, EMPTIME, ESTARTDATE, EENDDATE FROM EMP_PROJ_ACT WHERE EMPNO = {0} AND PROJ_NO = {1} AND ACT_NO = {2}";

			//prepare query by replacing place holders
			getEmpProjActDetailsQuery = string.Format(getEmpProjActDetailsQuery, employeeNo, projectNo, activityNo.ToString());

			//execute query 
			orclDR = OracleHelper.ExecuteReader(GetOrclDBConnString, 
				CommandType.Text, 
				getEmpProjActDetailsQuery);

			//read data from oracle reader
			if (orclDR.Read())
			{
				//make new empProjActDTO and populate
				empProjActDTO = new ProjectDTO();

				empProjActDTO.ProjectEmployee	= orclDR.GetString(orclDR.GetOrdinal("EMPNO"));
				empProjActDTO.ProjectNo			= orclDR.GetString(orclDR.GetOrdinal("PROJ_NO"));
				empProjActDTO.ActivityNo		= orclDR.GetInt32(orclDR.GetOrdinal("ACT_NO"));
				empProjActDTO.EmployeeTime		= orclDR.GetFloat(orclDR.GetOrdinal("EMPTIME"));
				empProjActDTO.ProjectStartDate	= orclDR.GetDateTime(orclDR.GetOrdinal("ESTARTDATE"));
				empProjActDTO.ProjectEndDate	= orclDR.GetDateTime(orclDR.GetOrdinal("EENDDATE"));
			}
			else
			{
				empProjActDTO = null;
			}
			return empProjActDTO;
		}

	
		/// <summary>
		///  this method updates employee project acivity details in EMP_PROJ_ACT table
		/// </summary>
		/// <param name="empProjActDTO"></param>
		public void UpdateEmployeeProjectActivityDetails(ProjectDTO empProjActDTO)
		{
			//declaration
			string[] empProjActValues;
			string updateEmpProjActDetailsQuery;
			empProjActValues = new string[5];

			empProjActValues[0] = empProjActDTO.ProjectEmployee;
			empProjActValues[1] = empProjActDTO.ProjectNo;
			empProjActValues[2] = empProjActDTO.ActivityNo.ToString();
			empProjActValues[3] = empProjActDTO.EmployeeTime.ToString();
			empProjActValues[4] = empProjActDTO.ProjectStartDate.ToString();
			empProjActValues[5] = empProjActDTO.ProjectEndDate.ToString();

			//write embedded query
			updateEmpProjActDetailsQuery = "UPDATE EMP_PROJ_ACT SET EMPTIME = {3}, ESTARTDATE = TO_DATE( {4}, 'MM/DD/YYYY HH:MI:SS AM'), EENDDATE = TO_DATE( {5}, 'MM/DD/YYYY HH:MI:SS AM') WHERE EMPNO = {0} AND PROJ_NO = {1} AND ACT_NO = {2}";
			
			//format the query to replace place holders with their values
			updateEmpProjActDetailsQuery = string.Format(updateEmpProjActDetailsQuery, empProjActValues);
		
			//call oracle helper to update details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				updateEmpProjActDetailsQuery);
		}

	
		/// <summary>
		///  this method adds new employee project activity details
		/// </summary>
		/// <param name="empProjActDTO"></param>
		public void AddEmployeeProjectActivityDetails(ProjectDTO empProjActDTO)
		{

			//declaration
			string[] empProjActValues;
			string addEmpProjActDetailsQuery;
			empProjActValues = new string[5];

			empProjActValues[0] = empProjActDTO.ProjectEmployee;
			empProjActValues[1] = empProjActDTO.ProjectNo;
			empProjActValues[2] = empProjActDTO.ActivityNo.ToString();
			empProjActValues[3] = empProjActDTO.EmployeeTime.ToString();
			empProjActValues[4] = empProjActDTO.ProjectStartDate.ToString();
			empProjActValues[5] = empProjActDTO.ProjectEndDate.ToString();

			//write embedded query
			addEmpProjActDetailsQuery = "INSERT INTO EMP_PROJ_ACT " +
										   " ( EMPNO, PROJ_NO, ACT_NO, EMPTIME, ESTARTDATE,EENDDATE )" + 
										   " VALUES " +
										   " ( {}, {}, {}, {},  TO_Date( {}, 'MM/DD/YYYY HH:MI:SS AM'),  TO_Date({}, 'MM/DD/YYYY HH:MI:SS AM'))"; 
			
			//format the query to replace place holders with their values
			addEmpProjActDetailsQuery = string.Format(addEmpProjActDetailsQuery, empProjActValues);
		
			//call oracle helper to update details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				addEmpProjActDetailsQuery);

		}

	
		/// <summary>
		/// delete employee project activity details
		/// </summary>
		/// <param name="emplyeeNo"></param>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
		public void DeleteEmployeeProjectActivityDetails(string emplyeeNo, string projectNo, int activityNo)
		{
			//declaration
			string deleteEmpProjActDetailsQuery;

			//write embedded query
			deleteEmpProjActDetailsQuery = "DELETE FROM EMP_PROJ_ACT WHERE EMPNO = {0} AND PROJ_NO = {1} AND ACT_NO = {2}";

			//format the query to replace place holders with their values
			deleteEmpProjActDetailsQuery = string.Format(deleteEmpProjActDetailsQuery, emplyeeNo, projectNo, activityNo.ToString());

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				deleteEmpProjActDetailsQuery);
		}

	
		#endregion


		#region "Queries for MSG_IN_TRAY table"

		/// <summary>
		///  method to get message details
		///  this message gets all the messages belonging to given employee
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <returns></returns>
		public DataSet GetMsgInTrayDetails(string employeeNo)
		{

			//declaration
			DataSet messageDetailsDataset;
			string getMsgInTrayDetailsQuery;

			//write embedded query
			getMsgInTrayDetailsQuery = "SELECT EMPNO, RECEIVED, SOURCE, SUBJECT, NOTE_TEXT FROM MSG_IN_TRAY WHERE EMPNO = {0}";

			//format the query to replace place holders with their values
			getMsgInTrayDetailsQuery = string.Format(getMsgInTrayDetailsQuery, employeeNo);

			//execute query 
			messageDetailsDataset = OracleHelper.ExecuteDataset(GetOrclDBConnString, 
				CommandType.Text, 
				getMsgInTrayDetailsQuery);

		return messageDetailsDataset;
		}


		/// <summary>
		///  this method updates a message MSG_IN_TRAY table
		/// </summary>
		/// <param name="messageDTO"></param>
		public void UpdateMsgInTrayDetails(MessageDTO messageDTO)
		{
			//declaration
			string[] msgValues;
			string updateMsgInTrayDetailsQuery;
			msgValues = new string[2];

			msgValues[0] = messageDTO.EmployeeNo;
			msgValues[1] = messageDTO.ReceivedTime.ToString();
			msgValues[2] = messageDTO.NoteText;

			//write embedded query
			updateMsgInTrayDetailsQuery = "UPDATE MSG_IN_TRAY SET NOTE_TEXT = {2} WHERE EMPNO = {0} AND RECEIVED = TO_DATE( {1}, 'MM/DD/YYYY HH:MI:SS AM')";
			
			//format the query to replace place holders with their values
			updateMsgInTrayDetailsQuery = string.Format(updateMsgInTrayDetailsQuery, msgValues);
		
			//call oracle helper to update details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				updateMsgInTrayDetailsQuery);
		}


		/// <summary>
		///  this method adds new message details
		/// </summary>
		/// <param name="empProjActDTO"></param>
		public void AddMsgInTrayDetails(MessageDTO messageDTO)
		{

			//declaration
			string[] messageValues;
			string addMsgInTrayDetailsQuery;
			messageValues = new string[4];

			messageValues[0] = messageDTO.EmployeeNo;
			messageValues[1] = messageDTO.ReceivedTime.ToString();
			messageValues[2] = messageDTO.Source;
			messageValues[3] = messageDTO.Subject;
			messageValues[4] = messageDTO.NoteText;

			//write embedded query
			addMsgInTrayDetailsQuery = "INSERT INTO MSG_IN_TRAY " + 
										"( EMPNO, RECEIVED, SOURCE, SUBJECT, NOTE_TEXT )" +
									    " VALUES" +
										" ( {0},{1},{2},{3},{4})"; 
			
			//format the query to replace place holders with their values
			addMsgInTrayDetailsQuery = string.Format(addMsgInTrayDetailsQuery, messageValues);
		
			//call oracle helper to update details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				addMsgInTrayDetailsQuery);

		}


		/// <summary>
		///  method to delete message from msg_in_tray table
		/// </summary>
		/// <param name="emplyeeNo"></param>
		/// <param name="received"></param>
		public void DeleteMsgInTrayDetails(string emplyeeNo, DateTime received)
		{
			//declaration
			string deleteMsgInTrayDetailsQuery;

			//write embedded query
			deleteMsgInTrayDetailsQuery = "DELETE FROM MSG_IN_TRAY WHERE EMPNO = {0} AND RECEIVED = TO_DATE({1},'MM/DD/YYYY HH:MI:SS AM')";
			
			//format the query to replace place holders with their values
			deleteMsgInTrayDetailsQuery = string.Format(deleteMsgInTrayDetailsQuery, emplyeeNo, received.ToString());

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				deleteMsgInTrayDetailsQuery);
		}

		#endregion


		#region "Queries for EMP, EMP_PHOTO, EMP_RESUME table"

		/// <summary>
		///  This method gets employee full details
		///  this method uses parametes to pass employee number
		///  this method calls stored procedure to get the details.
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <returns></returns>
		public EmployeeDTO GetEmployeeDetails(string employeeNo)
		{

			//declaration
			EmployeeDTO employeeDTO;
			OracleDataReader orclDR;
			OracleParameter[] empParam;

			empParam = new OracleParameter[16];

			//Assign value and direction to the parameters

			//employee 
			empParam[0]				= new OracleParameter("I_EMPLOYEE_NO", OracleType.Char);
			empParam[0].Value		= employeeNo;
			empParam[0].Direction	= ParameterDirection.Input;

			//O_FIRSTNAME 
			empParam[1]				= new OracleParameter("O_FIRSTNAME", OracleType.VarChar);
			empParam[1].Direction	= ParameterDirection.Output;

			//O_MIDNAME 
			empParam[2]				= new OracleParameter("O_MIDNAME", OracleType.Char);
			empParam[2].Direction	= ParameterDirection.Output;

			//O_LASTNAME 
			empParam[3]				= new OracleParameter("O_LASTNAME", OracleType.VarChar);
			empParam[3].Direction	= ParameterDirection.Output;

			//O_WORKDEPT 
			empParam[4]				= new OracleParameter("O_WORKDEPT", OracleType.Char);
			empParam[4].Direction	= ParameterDirection.Output;

			//O_PHONENO 
			empParam[5]				= new OracleParameter("O_PHONENO", OracleType.Char);
			empParam[5].Direction	= ParameterDirection.Output;

			//O_HIREDATE 
			empParam[6]				= new OracleParameter("O_HIREDATE", OracleType.DateTime);
			empParam[6].Direction	= ParameterDirection.Output;

			//O_JOB 
			empParam[7]				= new OracleParameter("O_JOB", OracleType.Char);
			empParam[7].Direction	= ParameterDirection.Output;

			//O_SEX 
			empParam[8]				= new OracleParameter("O_SEX", OracleType.Char);
			empParam[8].Direction	= ParameterDirection.Output;

			//O_BIRTHDATE 
			empParam[9]				= new OracleParameter("O_BIRTHDATE", OracleType.DateTime);
			empParam[9].Direction	= ParameterDirection.Output;

			//O_SALARY 
			empParam[10]				= new OracleParameter("O_SALARY", OracleType.Number);
			empParam[10].Direction	= ParameterDirection.Output;

			//O_BONUS 
			empParam[11]				= new OracleParameter("O_BONUS", OracleType.Number);
			empParam[11].Direction	= ParameterDirection.Output;

			//O_EMPLOYEEPHOTO 
			empParam[12]				= new OracleParameter("O_EMPLOYEEPHOTO", OracleType.Blob);
			empParam[12].Direction	= ParameterDirection.Output;

			//O_PHOTO_FORMAT 
			empParam[13]				= new OracleParameter("O_PHOTO_FORMAT", OracleType.VarChar);
			empParam[13].Direction	= ParameterDirection.Output;

			//O_EMPLOYEE_RESUME 
			empParam[14]				= new OracleParameter("O_EMPLOYEE_RESUME", OracleType.Clob);
			empParam[14].Direction	= ParameterDirection.Output;

			//O_RESUME_FORMAT 
			empParam[15]				= new OracleParameter("O_RESUME_FORMAT", OracleType.VarChar);
			empParam[15].Direction	= ParameterDirection.Output;


			//get employee details
			orclDR = OracleHelper.ExecuteReader(GetOrclDBConnString, 
				CommandType.StoredProcedure, 
				"GET_EMPLOYEEDETAILS");

			//read data from oracle reader
			if (orclDR.Read())
			{
				//make new employeeDTO and populate
				employeeDTO = new EmployeeDTO();

				employeeDTO.EmployeeNo			= empParam[0].Value.ToString();
				employeeDTO.FirstName			= empParam[1].Value.ToString();
				employeeDTO.MidName				= empParam[2].Value.ToString();
				employeeDTO.LastName			= empParam[3].Value.ToString();
				employeeDTO.WorkDepartmentNo	= empParam[4].Value.ToString();
				employeeDTO.PhoneNo				= empParam[5].Value.ToString();
				employeeDTO.HireDate			= (DateTime)empParam[6].Value;
				employeeDTO.Job					= empParam[7].Value.ToString();
				employeeDTO.Sex					= (int)empParam[8].Value;
				employeeDTO.BirthDate			= (DateTime)empParam[9].Value;
				employeeDTO.Salary				= (int)empParam[10].Value;
				employeeDTO.Bonus				= (int)empParam[11].Value;
				employeeDTO.EmployeePhoto		= empParam[12].Value.ToString();
				employeeDTO.EmployeePhotoFormat = empParam[13].Value.ToString();
				employeeDTO.EmployeeResume		= empParam[14].Value.ToString();
				employeeDTO.EmployeeResumeFormat = empParam[15].Value.ToString();

			}
			else
			{
				employeeDTO = null;
			}
			return employeeDTO;
		}


		/// <summary>
		///  this method update employee details but not employee photo and employee resume
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void UpdateEmployeeDetails(EmployeeDTO employeeDTO)
		{
			//declaration
			string[] employeeValues;
			string updateEmployeeDetailsQuery;

			employeeValues = new string[3];

			employeeValues[0] = employeeDTO.EmployeeNo;
			employeeValues[1] = employeeDTO.Salary.ToString();
			employeeValues[2] = employeeDTO.Bonus.ToString();
			employeeValues[3] = employeeDTO.Commission.ToString();

			//write embedded query
			updateEmployeeDetailsQuery = "UPDATE EMP SET SALARY = {1}, BONUS = {2}, COMM = {3} WHERE EMPNO = {0}";

			//format the query to replace place holders with their values
			updateEmployeeDetailsQuery = string.Format(updateEmployeeDetailsQuery, employeeValues);

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				updateEmployeeDetailsQuery);

		}


		/// <summary>
		///  this method updates empoyee photo in EMP_PHOTO table
		/// </summary>
		/// <param name="emplyeeDTO"></param>
		public void UpdateEmployeePhoto(EmployeeDTO emplyeeDTO)
		{
			//declaration
			string updateEmployeePhotoQuery;
			OracleParameter[] empPhotoDetails;


			empPhotoDetails = new OracleParameter[2];
			
			//use parameter for uploading photo

			empPhotoDetails[0] = new OracleParameter("emp_photo", OracleType.Blob);
			empPhotoDetails[0].Value = emplyeeDTO.EmployeePhoto;

			empPhotoDetails[1] = new OracleParameter("emp_photo_format", OracleType.VarChar);
			empPhotoDetails[1].Value = emplyeeDTO.EmployeePhotoFormat;

			empPhotoDetails[2] = new OracleParameter("emp_no", OracleType.Char);
			empPhotoDetails[2].Value = emplyeeDTO.EmployeeNo;

			//write embedded query
			updateEmployeePhotoQuery = "UPDATE EMP_PHOTO SET PICTURE = ?, PHOTO_FORMAT = ? WHERE EMP_NO = ?";

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				updateEmployeePhotoQuery, 
				empPhotoDetails);

		}

	
		/// <summary>
		///  this method updates empoyee resume in EMP_RESUME table
		/// </summary>
		/// <param name="emplyeeDTO"></param>
		public void UpdateEmployeeResume(EmployeeDTO emplyeeDTO)
		{
			//declaration
			string updateEmployeeResumeQuery;
			OracleParameter[] empResumeDetails;

			empResumeDetails = new OracleParameter[2];

			//use parameter for uploading photo

			empResumeDetails[0] = new OracleParameter("emp_resume", OracleType.Clob);
			empResumeDetails[0].Value = emplyeeDTO.EmployeeResume;

			empResumeDetails[1] = new OracleParameter("emp_resume_format", OracleType.VarChar);
			empResumeDetails[1].Value = emplyeeDTO.EmployeeResumeFormat;

			empResumeDetails[2] = new OracleParameter("emp_no", OracleType.Char);
			empResumeDetails[2].Value = emplyeeDTO.EmployeeNo;

			//write embedded query
			updateEmployeeResumeQuery = "UPDATE EMP_RESUME SET RESUME = ?, RESUME_FORMAT = ? WHERE EMP_NO = ?";

			//call oracle helper to update project details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				updateEmployeeResumeQuery, 
				empResumeDetails);

		}


		/// <summary>
		///  add new employee
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void AddNewEmployee(EmployeeDTO employeeDTO)
		{

			//declaration
			string[] empValues;
			string addEmployeeDetailsQuery;
			empValues = new string[13];

			empValues[0] = employeeDTO.EmployeeNo;
			empValues[1] = employeeDTO.FirstName;
			empValues[2] = employeeDTO.MidName;
			empValues[3] = employeeDTO.LastName;
			empValues[4] = employeeDTO.WorkDepartmentNo;
			empValues[5] = employeeDTO.PhoneNo;
			empValues[6] = employeeDTO.HireDate.ToString();
			empValues[7] = employeeDTO.Job;
			empValues[8] = employeeDTO.EdLevel.ToString();
			empValues[9] = employeeDTO.Sex.ToString();
			empValues[10] = employeeDTO.BirthDate.ToString();
			empValues[11] = employeeDTO.Salary.ToString();
			empValues[12] = employeeDTO.Bonus.ToString();
			empValues[13] = employeeDTO.Commission.ToString();

			//***************************************************//
			//update employee table
			//***************************************************//

			//write embedded query
			addEmployeeDetailsQuery = "INSERT INTO EMP " +
				" ( EMPNO, FIRSTNAME, MIDINIT, LASTNAME, WORKDEPT, PHONENO, HIREDATE, JOB, EDLEVEL, SEX, BIRTHDATE, SALARY, BONUS, COMM)" + 
				" VALUES " +
				" ( {0}, {1}, {2}, {3}, {4}, {5}, TO_Date( {6}, 'MM/DD/YYYY HH:MI:SS AM'), {7}, {8}, {9}, TO_Date( {10}, 'MM/DD/YYYY HH:MI:SS AM'), {11}, {12}, {13})"; 

			//format the query to replace place holders with their values
			addEmployeeDetailsQuery = string.Format(addEmployeeDetailsQuery, empValues);
		
			//call oracle helper to update details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				addEmployeeDetailsQuery);

		}


		/// <summary>
		///  add new employee photo
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void AddNewEmployeePhoto(EmployeeDTO employeeDTO)
		{

			//declaration
			string addEmployeeDetailsQuery;

			OracleParameter[] empPhotoParam;

			empPhotoParam = new OracleParameter[1];

			empPhotoParam[0]		= new OracleParameter("emp_photo", OracleType.Blob);
			empPhotoParam[0].Value	= employeeDTO.EmployeePhoto;

			empPhotoParam[1]		= new OracleParameter("emp_photo_format", OracleType.VarChar);
			empPhotoParam[1].Value	= employeeDTO.EmployeePhotoFormat;

			//***************************************************//
			//update employee photo table with new employee number
			//***************************************************//
			
			//write embedded query
			addEmployeeDetailsQuery = "INSERT INTO EMP_PHOTO " +
				" ( EMPNO, PICTURE, PHOTO_FORMAT )" + 
				" VALUES " +
				" ( {0}, ?, ?)"; 

			//format the query to replace place holders with their values
			addEmployeeDetailsQuery = string.Format(addEmployeeDetailsQuery, employeeDTO.EmployeeNo);
		
			//call oracle helper to update details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				addEmployeeDetailsQuery,
				empPhotoParam);

		}

	
		/// <summary>
		///  add new employee resume
		/// </summary>
		/// <param name="employeeDTO"></param>
	
		public void AddNewEmployeeResume(EmployeeDTO employeeDTO)
		{

			//declaration
			string addEmployeeDetailsQuery;
			OracleParameter[] empResumeParam;

			empResumeParam = new OracleParameter[1];

			empResumeParam[0]		= new OracleParameter("emp_resume", OracleType.Clob);
			empResumeParam[0].Value	= employeeDTO.EmployeeResume;

			empResumeParam[1]		= new OracleParameter("emp_resume_format", OracleType.VarChar);
			empResumeParam[1].Value	= employeeDTO.EmployeeResumeFormat;

			//***************************************************//
			//insert into employee resume table 
			//***************************************************//
			
			//write embedded query
			addEmployeeDetailsQuery = "INSERT INTO EMP_RESUME " +
				" ( EMPNO, RESUME, RESUME_FORMAT )" + 
				" VALUES " +
				" ( {0}, ?, ?)"; 

			//format the query to replace place holders with their values
			addEmployeeDetailsQuery = string.Format(addEmployeeDetailsQuery, employeeDTO.EmployeeNo);
		
			//call oracle helper to update details
			OracleHelper.ExecuteNonQuery(GetOrclDBConnString,
				CommandType.Text,
				addEmployeeDetailsQuery,
				empResumeParam);
		}


		#endregion

	}
}