// ===============================================================================
// This class uses Microsoft configuration management block for reading config files.
//
// DbConfigurationData.cs
//
// The class that contains the configuration for hrManagement application
//
// ==============================================================================

using System;
using System.Drawing;
using System.Xml;

namespace MyTelco.Data.hrDAC
{                
	public class DbConfigurationData
	{

		//constructor
		public DbConfigurationData()
		{
		}

		//******************** Oracle connection string ************************
		string _OrclDBConnectionString;

		public string OrclDBConnectionString
		{
			get{ return _OrclDBConnectionString; }
			set{ _OrclDBConnectionString = value; }
		} 

		//******************** Sql connection string ************************
		string _SqlDBConnectionString;

		public string SqlDBConnectionString
		{
			get{ return _SqlDBConnectionString; }
			set{ _SqlDBConnectionString = value; }
		} 

		//******************** NoOfRetries string ************************
		int _NoOfRetries;

		public int NoOfRetries
		{
			get{ return _NoOfRetries; }
			set{ _NoOfRetries = value; }
		} 

		//******************** GetProjectDetailsQuery string************************
		string _GetProjectDetailsQuery;

		public string GetProjectDetailsQuery
		{
			get{ return _GetProjectDetailsQuery; }
			set{ _GetProjectDetailsQuery = value; }
		} 
	
		//******************** UpdateProjectDetailsQuery string************************
		string _UpdateProjectDetailsQuery;

		public string UpdateProjectDetailsQuery
		{
			get{ return _UpdateProjectDetailsQuery; }
			set{ _UpdateProjectDetailsQuery = value; }
		} 

		//******************** InsertProjectDetailsQuery string************************
		string _InsertProjectDetailsQuery;

		public string InsertProjectDetailsQuery
		{
			get{ return _InsertProjectDetailsQuery; }
			set{ _InsertProjectDetailsQuery = value; }
		} 
	}
}
