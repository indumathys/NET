using System;
using MyTelco.Business.hrDTO;

namespace MyTelco.Data.hrDAC
{
	/// <summary>
	/// Summary description for IProjectDataProvider.
	/// </summary>
	public interface IProjectDataProvider
	{
		/// <summary>
		/// This method gets projects details and populated ProjectDTO 
		/// with the project details.
		/// </summary>
		/// <param name="projectNo"></param>
		/// <returns></returns>
		ProjectDTO GetProjectDetails(string projectNo);

	}
}
