// ===============================================================================
// This class uses Microsoft configuration management block for reading config files.
//
// DbSectionHandler.cs
//
// The section handler that uses the XmlSerializer class to store to convert
// the CDbConfigurationData class into an XmlNode
//
// ==============================================================================

using System;
using System.Configuration;
using System.IO;
using System.Runtime.InteropServices;
using System.Xml;
using System.Xml.Serialization;

using Microsoft.ApplicationBlocks.ConfigurationManagement;

namespace MyTelco.Data.hrDAC
{
	[ComVisible(false)]
	public class DbSectionHandler
		: IConfigurationSectionHandler, IConfigurationSectionHandlerWriter
	{
		XmlSerializer xs = new XmlSerializer( typeof(DbConfigurationData) );

		public object Create( object parent, object hmm, XmlNode configSection )
		{ 
			object tmpObj = null;
			tmpObj = xs.Deserialize( new StringReader( configSection.OuterXml ) );
			return (DbConfigurationData)tmpObj;
		}

		public XmlNode Serialize( object value )
		{
            try
            {
                StringWriter sw = new StringWriter( System.Globalization.CultureInfo.CurrentUICulture );
                xs.Serialize( sw, value );
                XmlDocument doc = new XmlDocument();
                doc.LoadXml( sw.ToString() );
                return doc.ChildNodes[1];
            }
            catch( Exception e )
            {
                throw new ConfigurationException( "The section handler can't be serialized", e ); 
            }
		}
	}
}
