using System;
using System.Data;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Threading;

namespace MyTelco.Data.hrDAC
{
	/// <summary>
	/// Summary description for BaseDAC.
	/// </summary>
	public abstract class BaseDAC
	{

		private const int SLEEP_TIME = 20;


		#region "connection methods for Oracle Server"

		/// <summary>
		/// get Oracle connection string from db.config configuration file
		/// </summary>
		protected string GetOrclDBConnString
		{
			get{return DbReadConfigValues.orclDbConfig.OrclDBConnectionString;}
		}

		/// <summary>
		/// method to open new oracle connection
		/// </summary>
		/// <param name="connString"></param>
		/// <returns></returns>
		protected OracleConnection OpenOracleConnection(string connString)
		{
			OracleConnection connection;
			int counter;
			int NoOfRetries;

			try 
			{
				counter = 0;
				NoOfRetries = DbReadConfigValues.orclDbConfig.NoOfRetries;

				//Sets connection object
				connection = new OracleConnection(connString);

				//retries for opening the connection
				while ((counter <= NoOfRetries) & (connection.State != ConnectionState.Open))
				{
					try
					{
						//Trying to open the connection 
						connection.Open();
					}
					catch(Exception ex)
					{
						//If the application retries the number of times as mentioned in config
						//file and is unsuccessful it throws back an exception
						if (counter == NoOfRetries)
						{
							throw ex;
						} 
						else
						{
							counter += 1;
							//Log admin message into Log File
							Thread.Sleep(SLEEP_TIME);
						}
					}
				}
				//Returns the connection in case it is able to establish a connection
				return connection;
			}
			catch(OracleException ex)
			{
				//ideally the exception message should be logged and then thrown. 
				throw ex;
			}
		}


		/// <summary>
		/// method to close oracle connection
		/// </summary>
		/// <param name="connection"></param>
		protected void CloseOracleConnection(OracleConnection connection)
		{
			if (connection != null)
			{
				if (connection.State == ConnectionState.Open)
				{
					connection.Close();
				}
			}
		}

		#endregion

		#region "connection methods for SQL Server"

		/// <summary>
		/// get Oracle connection string from db.config configuration file
		/// </summary>
		protected string GetSQLDBConnString
		{
			get{return DbReadConfigValues.sqlDbConfig.SqlDBConnectionString;}
		}


		/// <summary>
		/// method to open new SQL connection
		/// </summary>
		/// <param name="connString"></param>
		/// <returns></returns>
		protected SqlConnection OpenSQLConnection(string connString)
		{
			SqlConnection connection;
			int counter;
			int NoOfRetries;

			try 
			{
				counter = 0;
				NoOfRetries = DbReadConfigValues.sqlDbConfig.NoOfRetries;

				//Sets connection object
				connection = new SqlConnection(connString);

				//retries for opening the connection
				while ((counter <= NoOfRetries) & (connection.State != ConnectionState.Open))
				{
					try
					{
						//Trying to open the connection 
						connection.Open();
					}
					catch(Exception ex)
					{
						//If the application retries the number of times as mentioned in config
						//file and is unsuccessful it throws back an exception
						if (counter == NoOfRetries)
						{
							throw ex;
						} 
						else
						{
							counter += 1;
							//Log admin message into Log File
							Thread.Sleep(SLEEP_TIME);
						}
					}
				}
				//Returns the connection in case it is able to establish a connection
				return connection;
			}
			catch(SqlException ex)
			{
				//ideally the exception message should be logged and then thrown. 
				throw ex;
			}
		}


		/// <summary>
		/// method to close SQL connection
		/// </summary>
		/// <param name="connection"></param>
		protected void CloseSQLConnection(SqlConnection connection)
		{
			if (connection != null)
			{
				if (connection.State == ConnectionState.Open)
				{
					connection.Close();
				}
			}
		}

		#endregion
	}
}
