using System;
using MyTelco.Data.hrDAC;

namespace MyTelco.Business.hrBO
{
	/// <summary>
	/// Summary description for RecruitmentBO.
	/// </summary>
	public class RecruitmentBO
	{

		/// <summary>
		/// constructor
		/// </summary>
		public RecruitmentBO()
		{
		}

		/// <summary>
		///  This method returns available openinings 
		///  based on the search criteria sent by the user
		///  
		/// <param name="requiredSkills"></param>
		/// <param name="requiredExperience"></param>
		/// <returns></returns>
		public string SearchOpenings(string requiredSkills, int requiredExperience)
		{
			//declaration
			RecruitmentDAC recruitDAC;
			string openings;

			recruitDAC = new RecruitmentDAC();
			openings = recruitDAC.SearchOpenings(requiredSkills, requiredExperience);

			return openings;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="jobCode"></param>
		/// <param name="candidateName"></param>
		/// <param name="DOB"></param>
		/// <param name="Address"></param>
		/// <param name="phone"></param>
		/// <param name="email"></param>
		/// <param name="resume"></param>
		/// <param name="source"></param>
		public void ApplyForJob(string jobCode, string candidateName, DateTime DOB, string Address, string phone, string email, object resume, string source)
		{
			//declaration
			RecruitmentDAC recruitDAC;

			recruitDAC = new RecruitmentDAC();
			recruitDAC.ApplyForJob(jobCode, candidateName, DOB, Address, phone, email, resume, source);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="candidateCode"></param>
		/// <returns></returns>
		public Object ViewCandidateResume(int candidateCode)
		{
			//declaration
			RecruitmentDAC recruitDAC;
			Object resume;

			recruitDAC = new RecruitmentDAC();
			resume = recruitDAC.ViewCandidateResume(candidateCode);
			return resume;

		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="candidateCode"></param>
		/// <param name="resume"></param>
		public void UpdateCandidateResume(int candidateCode, object resume)
		{
			//declaration
			RecruitmentDAC recruitDAC;

			recruitDAC = new RecruitmentDAC();
			recruitDAC.UpdateCandidateResume(candidateCode, resume);

		}	

		/// <summary>
		/// 
		/// </summary>
		/// <param name="candidateCode"></param>
		/// <param name="jobCode"></param>
		/// <param name="status"></param>
		/// <param name="source"></param>
		/// <param name="remarks"></param>
		public void UpdateCandidateStatus(int candidateCode, string jobCode,int status, string  source, string remarks)
		{
			//declaration
			RecruitmentDAC recruitDAC;

			recruitDAC = new RecruitmentDAC();
			recruitDAC.UpdateCandidateStatus(candidateCode, jobCode, status, source, remarks);

		}

	}
}
