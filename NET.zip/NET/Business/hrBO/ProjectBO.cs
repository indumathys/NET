using System;
using MyTelco.Business.hrDTO;
using MyTelco.Data.hrDAC;

namespace MyTelco.Business.hrBO
{
	/// <summary>
	/// Summary description for ProjectBO.
	/// </summary>
	public class ProjectBO
	{

		/// <summary>
		///  constructor
		/// </summary>
		public ProjectBO()
		{

		}

		/// <summary>
		///  apply business logic to get project details
		/// </summary>
		/// <param name="projectNo"></param>
		/// <returns></returns>
		public ProjectDTO GetProjectDetails(string projectNo)
		{
			//declare
			ProjectDTO projectDTO;
			ProjectDAC projectDAC;
 
			//object creation
			projectDAC = new ProjectDAC();

			//check that projectNo is of 6 characters
			if (projectNo.Length == 6)
			{
				//call dac method 
				projectDTO = projectDAC.GetProjectDetails(projectNo);
			}
			else
			{
				projectDTO = null;
				throw new FormatException("ProjectNo has incorrect length");
			}

			//return details
			return projectDTO;
		}

		/// <summary>
		/// This mehod applies business logic to update project details
		/// </summary>
		/// <param name="projectDTO"></param>
		public void UpdateProjectDetails(ProjectDTO projectDTO)
		{
			//declare
			ProjectDAC projectDAC;
 
			//object creation
			projectDAC = new ProjectDAC();

			///code to apply business logic to check correctness of update logic
			///For ex: check for valid start time and end time (can not be in past)
			
			//call dac method to update details
			projectDAC.UpdateProjectDetails(projectDTO);
			
		}
		
		/// <summary>
		///  This method aplies business logic for inserting a new project record
		/// </summary>
		/// <param name="projectDTO"></param>
		public void AddProjectDetails(ProjectDTO projectDTO)
		{
			//declare
			ProjectDAC projectDAC;
 
			//object creation
			projectDAC = new ProjectDAC();

			///code to apply business logic to check correctness of add project logic
			///For ex: check for valid start time and end time (can not be in past)

			
			//call dac method to update details
			projectDAC.AddProjectDetails(projectDTO);
		}
	}
}
