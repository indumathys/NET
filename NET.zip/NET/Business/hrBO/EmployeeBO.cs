using System;
using System.Data;
using MyTelco.Data.hrDAC;
using MyTelco.Business.hrDTO;
using MyTelco.Business.TxHelper;

namespace MyTelco.Business.hrBO
{
	/// <summary>
	/// Summary description for EmployeeBO.
	/// </summary>
	public class EmployeeBO
	{

		/// <summary>
		/// constructor
		/// </summary>
		public EmployeeBO()
		{
		}

		/// <summary>
		/// This method applies business logic for getting employee project activity details
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
		/// <returns></returns>
		public ProjectDTO GetEmployeeProjectActivityDetails(string employeeNo, string projectNo, int activityNo)
		{
			//declare
			EmployeeDAC employeeDAC;
			ProjectDTO empProjActDTO;

			//object creation
			employeeDAC = new EmployeeDAC();

			///apply business logic
			///

			//call dac method
			empProjActDTO = employeeDAC.GetEmployeeProjectActivityDetails(employeeNo, projectNo, activityNo);

			return empProjActDTO;
		}		

		/// <summary>
		/// This method applies business logic for updating 
		/// employee project activity details
		/// </summary>
		/// <param name="empProjActDTO"></param>
		public void UpdateEmployeeProjectActivityDetails(ProjectDTO empProjActDTO)
		{
			//declare
			EmployeeDAC employeeDAC;

			//object creation
			employeeDAC = new EmployeeDAC();

			///apply business logic
			///

			//call dac method
			employeeDAC.UpdateEmployeeProjectActivityDetails(empProjActDTO);

		}

		/// <summary>
		/// This method applies business logic for adding 
		/// employee project activity details
		/// </summary>
		/// <param name="empProjActDTO"></param>
		public void AddEmployeeProjectActivityDetails(ProjectDTO empProjActDTO)
		{
			//declare
			EmployeeDAC employeeDAC;

			//object creation
			employeeDAC = new EmployeeDAC();

			///apply business logic
			///

			//call dac method
			employeeDAC.AddEmployeeProjectActivityDetails(empProjActDTO);
		}
		
		/// <summary>
		/// This method applies business logic for deleting 
		/// employee project activity details
		/// </summary>
		/// <param name="emplyeeNo"></param>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
		public void DeleteEmployeeProjectActivityDetails(string emplyeeNo, string projectNo, int activityNo)
		{
			//declare
			EmployeeDAC employeeDAC;

			//object creation
			employeeDAC = new EmployeeDAC();

			///apply business logic
			///

			//call dac method
			employeeDAC.DeleteEmployeeProjectActivityDetails(emplyeeNo, projectNo, activityNo);
		}
		
		/// <summary>
		/// This method applies business logic for getting employee message details
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <returns></returns>
		public DataSet GetMsgInTrayDetails(string employeeNo)
		{
			//declare
			EmployeeDAC employeeDAC;
			DataSet messageDetailsDs;

			//object creation
			employeeDAC = new EmployeeDAC();

			///apply business logic
			///

			//call dac method
			messageDetailsDs = employeeDAC.GetMsgInTrayDetails(employeeNo);

			return messageDetailsDs;
		}
		
		/// <summary>
		/// This method applies business logic for updating employee message details
		/// </summary>
		/// <param name="messageDTO"></param>
		public void UpdateMsgInTrayDetails(MessageDTO messageDTO)
		{
			//declare
			EmployeeDAC employeeDAC;

			//object creation
			employeeDAC = new EmployeeDAC();

			///apply business logic
			///

			//call dac method
			employeeDAC.UpdateMsgInTrayDetails(messageDTO);
		}
		
		/// <summary>
		/// This method applies business logic for adding employee message details
		/// </summary>
		/// <param name="messageDTO"></param>
		public void AddMsgInTrayDetails(MessageDTO messageDTO)
		{
			//declare
			EmployeeDAC employeeDAC;

			//object creation
			employeeDAC = new EmployeeDAC();

			///apply business logic
			///

			//call dac method
			employeeDAC.AddMsgInTrayDetails(messageDTO);
		}
		
		/// <summary>
		/// This method applies business logic for deleting employee message details
		/// </summary>
		/// <param name="emplyeeNo"></param>
		/// <param name="received"></param>
		public void DeleteMsgInTrayDetails(string emplyeeNo, DateTime received)
		{
			//declare
			EmployeeDAC employeeDAC;

			//object creation
			employeeDAC = new EmployeeDAC();

			///apply business logic
			///

			//call dac method
			employeeDAC.DeleteMsgInTrayDetails(emplyeeNo, received);
		}
		
		/// <summary>
		/// This method applies business logic for getting employee details
		/// </summary>
		/// <param name="employeeNo"></param>
		/// <returns></returns>
		public EmployeeDTO GetEmployeeDetails(string employeeNo)
		{
			//declare
			EmployeeDAC employeeDAC;
			EmployeeDTO employeeDTO;

			//object creation
			employeeDAC = new EmployeeDAC();

			///apply business logic
			///

			//call dac method
			employeeDTO = employeeDAC.GetEmployeeDetails(employeeNo);

			return employeeDTO;
		}
		
		/// <summary>
		/// This method applies business logic for updating employee details
		/// This method calls the transation to update employee details
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void UpdateEmployeeDetails(EmployeeDTO employeeDTO)
		{
			//declare
			TxManager txManager;

			//object creation
			txManager = new TxManager();

			///apply business logic
			///

			//call transaction 
			txManager.UpdateEmployeeDetails(employeeDTO);
		}
		
		/// <summary>
		/// This method applies business logic for adding employee details
		/// This method calls transation to add employee details
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void AddNewEmployee(EmployeeDTO employeeDTO)
		{
			//declare
			TxManager txManager;

			//object creation
			txManager = new TxManager();

			///apply business logic
			///

			//call transaction 
			txManager.AddNewEmployee(employeeDTO);
		}
	}
}
