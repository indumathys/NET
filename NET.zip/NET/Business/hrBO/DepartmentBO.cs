using System;
using MyTelco.Business.hrDTO;
using MyTelco.Data.hrDAC;

namespace MyTelco.Business.hrBO
{
	/// <summary>
	/// Summary description for DepartmentBO.
	/// </summary>
	public class DepartmentBO
	{

		/// <summary>
		///  constructor
		/// </summary>
		public DepartmentBO()
		{
		}

	
		/// <summary>
		///  Method to get department details for a given department
		/// </summary>
		/// <param name="departmentNo"></param>
		/// <returns></returns>
		public DepartmentDTO GetDepartmentDetails(string departmentNo)
		{
			//declare
			DepartmentDAC departmentDAC;
			DepartmentDTO departmentDTO;

			//object creation
			departmentDAC = new DepartmentDAC();

			/// apply business logic if required for getting department details
			/// For Ex: check validity of department number string.
			
			//call dac method
			departmentDTO = departmentDAC.GetDepartmentDetails(departmentNo);

			//return DTO
			return departmentDTO;
		}


		/// <summary>
		///  Method to update department details
		/// </summary>
		/// <param name="departmentDTO"></param>
		public void UpdateDepartmentDetails(DepartmentDTO departmentDTO)
		{
			//declare
			DepartmentDAC departmentDAC;

			//object creation
			departmentDAC = new DepartmentDAC();

			/// apply business logic if required for updating department details
			/// For Ex: check validity of department number string, manager numbre, admin department etc.
			
			//call dac method
			departmentDAC.UpdateDepartmentDetails(departmentDTO);

		}
	}
}
