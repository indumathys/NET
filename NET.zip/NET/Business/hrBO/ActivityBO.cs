using System;
using MyTelco.Business.hrDTO;
using MyTelco.Data.hrDAC;

namespace MyTelco.Business.hrBO
{
	/// <summary>
	/// Summary description for ActivityBO.
	/// </summary>
	public class ActivityBO
	{

		/// <summary>
		///  constructor
		/// </summary>
		public ActivityBO()
		{
		}

		/// <summary>
		///  This method applies busines logic before getting activity details
		/// </summary>
		/// <param name="activityNo"></param>
		/// <returns></returns>
		public ActivityDTO GetActivityDetails(int activityNo)
		{
			//declare
			ActivityDAC activityDAC;
			ActivityDTO activityDTO;

			//object creation
			activityDAC = new ActivityDAC();

			///apply business logic before getting activity details
			///For Ex: check for valid activity number
			///

			//call dac method and return the DTO
			activityDTO = activityDAC.GetActivityDetails(activityNo);

			return activityDTO;
		}

		/// <summary>
		/// This method applies business logic for updating Activity details
		/// </summary>
		/// <param name="activityDTO"></param>
		public void UpdateActivityDetails(ActivityDTO activityDTO)
		{
			//declare
			ActivityDAC activityDAC;

			//object creation
			activityDAC = new ActivityDAC();

			///apply business logic before updating activity details
			///For Ex: check for valid activity attributes like starttime, endtime, valid project number
			///

			//call dac method 
			activityDAC.UpdateActivityDetails(activityDTO);

		}

		/// <summary>
		/// This method applies business logic for adding Activity details
		/// </summary>
		/// <param name="activityDTO"></param>
		public void AddActivityDetails(ActivityDTO activityDTO)
		{
			//declare
			ActivityDAC activityDAC;

			//object creation
			activityDAC = new ActivityDAC();

			///apply business logic before adding activity details
			///For Ex: check for valid activity attributes like starttime, endtime, valid project number
			///

			//call dac method 
			activityDAC.AddActivityDetails(activityDTO);
		}

		/// <summary>
		/// This method applies business logic getting Project activity details
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityDTO"></param>
		public void GetPActivityDetails(ref ProjectDTO pActivityDTO, ref ActivityDTO activityDTO)
		{
			//declare
			ActivityDAC activityDAC;

			//object creation
			activityDAC = new ActivityDAC();

			///apply business logic before getting project activity details 

			//call dac method 
			activityDAC.GetPActivityDetails(ref pActivityDTO, ref activityDTO);
		}

		/// <summary>
		/// This method applies business logic for updating Project activity details
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityNo"></param>
		public void UpdatePActivityDetails(ProjectDTO pActivityDTO, int activityNo)
		{
			//declare
			ActivityDAC activityDAC;

			//object creation
			activityDAC = new ActivityDAC();

			///apply business logic before updating project activity details 

			//call dac method 
			activityDAC.UpdatePActivityDetails(pActivityDTO, activityNo);
		}

		/// <summary>
		/// This method applies business logic for adding Project activity details
		/// </summary>
		/// <param name="pActivityDTO"></param>
		/// <param name="activityNo"></param>
		public void AddPActivityDetails(ProjectDTO pActivityDTO, int activityNo)
		{
			//declare
			ActivityDAC activityDAC;

			//object creation
			activityDAC = new ActivityDAC();

			///apply business logic before updating project activity details 
			///For Ex: check if activity with same does not already exists

			//call dac method 
			activityDAC.AddPActivityDetails(pActivityDTO, activityNo);
		}

		/// <summary>
		/// This method applies business logic for deleting Project activity details 
		/// </summary>
		/// <param name="projectNo"></param>
		/// <param name="activityNo"></param>
								
		public void DeletePActivityDetails(string projectNo, int activityNo)
		{
			//declare
			ActivityDAC activityDAC;

			//object creation
			activityDAC = new ActivityDAC();

			///apply business logic before updating project activity details 
			///For Ex: check if no project is actively depending on this activity

			//call dac method 
			activityDAC.DeletePActivityDetails(projectNo, activityNo);
		}
	}
}
