using System;
using System.Xml.Serialization;
using System.ComponentModel;

namespace MyTelco.Business.hrDTO
{
	/// <summary>
	/// EmployeeDTO can hold employee data.
	/// </summary>

	public class EmployeeDTO
	{

		//constructor
		public EmployeeDTO()
		{
		}

		//*********************** EmployeeNo element ***********************
		string _EmployeeNo;

		[XmlElement(ElementName = "EmployeeNo", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string EmployeeNo
		{
			get{return _EmployeeNo;}
			set{_EmployeeNo = value;}
		}

		//*********************** FirstName element ***********************
		string _FirstName;

		[XmlElement(ElementName = "FirstName", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string FirstName
		{
			get{return _FirstName;}
			set{_FirstName = value;}
		}

		//*********************** MidName element ***********************
		string _MidName;

		[XmlElement(ElementName = "MidName", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string MidName
		{
			get{return _MidName;}
			set{_MidName = value;}
		}

		//*********************** LastName element ***********************
		string _LastName;

		[XmlElement(ElementName = "LastName", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string LastName
		{
			get{return _LastName;}
			set{_LastName = value;}
		}

		//*********************** WorkDepartmentNo element ***********************
		string _WorkDepartmentNo;

		[XmlElement(ElementName = "WorkDepartmentNo", IsNullable = true, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string WorkDepartmentNo
		{
			get{return _WorkDepartmentNo;}
			set{_WorkDepartmentNo = value;}
		}

		//*********************** PhoneNo element ***********************
		string _PhoneNo;

		[XmlElement(ElementName = "PhoneNo", IsNullable = true, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string PhoneNo
		{
			get{return _PhoneNo;}
			set{_PhoneNo = value;}
		}


		//*********************** HireDate element ***********************
		DateTime _HireDate;

		[XmlElement(ElementName = "HireDate", IsNullable = true, DataType ="DateTime" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public DateTime HireDate
		{
			get{return _HireDate;}
			set{_HireDate = value;}
		}


		//*********************** Job element ***********************
		string _Job;

		[XmlElement(ElementName = "Job", IsNullable = true, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string Job
		{
			get{return _Job;}
			set{_Job = value;}
		}


		//*********************** EdLevel element ***********************
		int _EdLevel;

		[XmlElement(ElementName = "EdLevel", IsNullable = false, DataType ="integer" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public int EdLevel
		{
			get{return _EdLevel;}
			set{_EdLevel = value;}
		}

		//*********************** Sex element ***********************
		int _Sex;

		[XmlElement(ElementName = "Sex", IsNullable = true, DataType ="integer" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public int Sex
		{
			get{return _Sex;}
			set{_Sex = value;}
		}
		
		//*********************** BirthDate element ***********************
		DateTime _BirthDate;

		[XmlElement(ElementName = "BirthDate", IsNullable = true, DataType ="DateTime" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public DateTime BirthDate
		{
			get{return _BirthDate;}
			set{_BirthDate = value;}
		}

		//*********************** Salary element ***********************
		float _Salary;

		[XmlElement(ElementName = "Salary", IsNullable = true, DataType ="float" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public float Salary
		{
			get{return _Salary;}
			set{_Salary = value;}
		}


		//*********************** Bonus element ***********************
		float _Bonus;

		[XmlElement(ElementName = "Bonus", IsNullable = true, DataType ="float" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public float Bonus
		{
			get{return _Bonus;}
			set{_Bonus = value;}
		}

		//*********************** Commission element ***********************
		float _Commission;

		[XmlElement(ElementName = "Commission", IsNullable = true, DataType ="float" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public float Commission
		{
			get{return _Commission;}
			set{_Commission = value;}
		}

		//*********************** EmployeeResume element ***********************
		object _EmployeeResume;

		[XmlElement(ElementName = "EmployeeResume", IsNullable = true, DataType ="float" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public object EmployeeResume
		{
			get{return _EmployeeResume;}
			set{_EmployeeResume = value;}
		}

		//*********************** EmployeeResumeFormat element ***********************
		string _EmployeeResumeFormat;

		[XmlElement(ElementName = "EmployeeResumeFormat", IsNullable = true, DataType ="float" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string EmployeeResumeFormat
		{
			get{return _EmployeeResumeFormat;}
			set{_EmployeeResumeFormat = value;}
		}

		//*********************** EmployeePhoto element ***********************
		object _EmployeePhoto;

		[XmlElement(ElementName = "EmployeePhoto", IsNullable = true, DataType ="float" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public object EmployeePhoto
		{
			get{return _EmployeePhoto;}
			set{_EmployeePhoto = value;}
		}

		//*********************** EmployeePhotoFormat element ***********************
		string _EmployeePhotoFormat;

		[XmlElement(ElementName = "EmployeeResumeFormat", IsNullable = true, DataType ="float" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string EmployeePhotoFormat
		{
			get{return _EmployeePhotoFormat;}
			set{_EmployeePhotoFormat = value;}
		}
	}
}
