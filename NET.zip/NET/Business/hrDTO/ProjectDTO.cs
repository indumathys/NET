using System;
using System.Xml.Serialization;
using System.ComponentModel;


namespace MyTelco.Business.hrDTO
{
	/// <summary>
	///  ProjectDTO can hold project related data.
	/// </summary>
	[XmlType(TypeName ="ProjectDTO"), XmlRoot(), Serializable(), EditorBrowsable(EditorBrowsableState.Advanced)]
	public class ProjectDTO
	{
		//constructor
		public ProjectDTO()
		{
		}

		//*********************** ProjectNo element ***********************
		string _ProjectNo;

		[XmlElement(ElementName = "ProjectNo", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string ProjectNo
		{
			get{return _ProjectNo;}
			set{_ProjectNo = value;}
		}

		//*********************** ProjectName element ***********************
		string _ProjectName;

		[XmlElement(ElementName = "ProjectName", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string ProjectName
		{
			get{return _ProjectName;}
			set{_ProjectName = value;}
		}

		//*********************** DeptNo element ***********************
		string _DeptNo;

		[XmlElement(ElementName = "DeptNo", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string DeptNo
		{
			get{return _DeptNo;}
			set{_DeptNo = value;}
		}

		//*********************** ProjectEmployee element ***********************
		string _ProjectEmployee;

		[XmlElement(ElementName = "ProjectEmployee", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string ProjectEmployee
		{
			get{return _ProjectEmployee;}
			set{_ProjectEmployee = value;}
		}

		//*********************** EmployeeTime element ***********************
		float _EmployeeTime;

		[XmlElement(ElementName = "EmployeeTime", IsNullable = true, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public float EmployeeTime
		{
			get{return _EmployeeTime;}
			set{_EmployeeTime = value;}
		}

		//*********************** ActivityNo element ***********************
		int _ActivityNo;

		[XmlElement(ElementName = "_ActivityNo", IsNullable = true, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public int ActivityNo
		{
			get{return _ActivityNo;}
			set{_ActivityNo = value;}
		}

		//*********************** ProjectStaff element ***********************
		float _ProjectStaff;

		[XmlElement(ElementName = "ProjectStaff", IsNullable = true, DataType ="float" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public float ProjectStaff
		{
			get{return _ProjectStaff;}
			set{_ProjectStaff = value;}
		}
	
		//*********************** ProjectStartDate element ***********************
		DateTime _ProjectStartDate;

		[XmlElement(ElementName = "ProjectStartDate", IsNullable = true, DataType ="DateTime" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public DateTime ProjectStartDate
		{
			get{return _ProjectStartDate;}
			set{_ProjectStartDate = value;}
		}

		//*********************** ProjectEndDate element ***********************
		DateTime _ProjectEndDate;

		[XmlElement(ElementName = "ProjectEndDate", IsNullable = true, DataType ="DateTime" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public DateTime ProjectEndDate
		{
			get{return _ProjectEndDate;}
			set{_ProjectEndDate = value;}
		}

		//*********************** ControlProject element ***********************
		string _ControlProject;

		[XmlElement(ElementName = "ControlProject", IsNullable = true, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string ControlProject
		{
			get{return _ControlProject;}
			set{_ControlProject = value;}
		}

	}
}
