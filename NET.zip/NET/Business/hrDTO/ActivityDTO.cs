using System;
using System.Xml.Serialization;
using System.ComponentModel;

namespace MyTelco.Business.hrDTO
{
	/// <summary>
	/// ActivityDTO can hold Activity data.
	/// </summary>
	[XmlType(TypeName ="ActivityDTO"), XmlRoot(), Serializable(), EditorBrowsable(EditorBrowsableState.Advanced)]
	public class ActivityDTO
	{

		//constructor
		public ActivityDTO()
		{
		}

		//*********************** ActivityNo element ***********************
		int _ActivityNo;

		[XmlElement(ElementName = "ActivityNo", IsNullable = false, DataType ="integer" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public int ActivityNo
		{
			get{return _ActivityNo;}
			set{_ActivityNo = value;}
		}

		//*********************** ActivityKeyword element ***********************
		string _ActivityKeyword;

		[XmlElement(ElementName = "ActivityKeyword", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string ActivityKeyword
		{
			get{return _ActivityKeyword;}
			set{_ActivityKeyword = value;}
		}

		//*********************** ActivityDescription element ***********************
		string _ActivityDescription;

		[XmlElement(ElementName = "ActivityDescription", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string ActivityDescription
		{
			get{return _ActivityDescription;}
			set{_ActivityDescription = value;}
		}

	}
}
