using System;
using System.Xml.Serialization;
using System.ComponentModel;

namespace MyTelco.Business.hrDTO
{
	/// <summary>
	/// MessageDTO can hold employee message data.
	/// </summary>
	[XmlType(TypeName ="MessageDTO"), XmlRoot(), Serializable(), EditorBrowsable(EditorBrowsableState.Advanced)]
	public class MessageDTO
	{
		//constructor
		public MessageDTO()
		{
		}

		//*********************** EmployeeNo element ***********************
		string _EmployeeNo;

		[XmlElement(ElementName = "EmployeeNo", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string EmployeeNo
		{
			get{return _EmployeeNo;}
			set{_EmployeeNo = value;}
		}

		//*********************** ReceivedTime element ***********************
		DateTime _ReceivedTime;
		
		[XmlElement(ElementName = "ReceivedTime", IsNullable = false, DataType ="DateTime" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public DateTime ReceivedTime
		{
			get{return _ReceivedTime;}
			set{_ReceivedTime = value;}
		}


		//*********************** Source element ***********************
		string _Source;
		
		[XmlElement(ElementName = "Source", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string Source
		{
			get{return _Source;}
			set{_Source = value;}
		}
		
		//*********************** Subject element ***********************
		string _Subject;
		
		[XmlElement(ElementName = "Subject", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string Subject
		{
			get{return _Subject;}
			set{_Subject = value;}
		}
		
		//*********************** NoteText element ***********************
		string _NoteText;
		
		[XmlElement(ElementName = "NoteText", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string NoteText
		{
			get{return _NoteText;}
			set{_NoteText = value;}
		}
		
	}
}
