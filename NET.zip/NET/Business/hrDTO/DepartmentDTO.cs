using System;
using System.Xml.Serialization;
using System.ComponentModel;

namespace MyTelco.Business.hrDTO
{
	/// <summary>
	/// DepartmentDTO can hold Department data.
	/// </summary>
	[XmlType(TypeName ="DepartmentDTO"), XmlRoot(), Serializable(), EditorBrowsable(EditorBrowsableState.Advanced)]
	public class DepartmentDTO
	{

		//constructor
		public DepartmentDTO()
		{
		}

		//*********************** DeptNo element ***********************
		string _DeptNo;

		[XmlElement(ElementName = "DeptNo", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string DeptNo
		{
			get{return _DeptNo;}
			set{_DeptNo = value;}
		}

		//*********************** DeptName element ***********************
		string _DeptName;

		[XmlElement(ElementName = "DeptName", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string DeptName
		{
			get{return _DeptName;}
			set{_DeptName = value;}
		}
		
		//*********************** ManagerNo element ***********************
		string _ManagerNo;

		[XmlElement(ElementName = "ManagerNo", IsNullable = true, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string ManagerNo
		{
			get{return _ManagerNo;}
			set{_ManagerNo = value;}
		}

		//*********************** AdminDeptNo element ***********************
		string _AdminDeptNo;

		[XmlElement(ElementName = "AdminDeptNo", IsNullable = false, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string AdminDeptNo
		{
			get{return _AdminDeptNo;}
			set{_AdminDeptNo = value;}
		}
		
		//*********************** Location element ***********************
		string _Location;

		[XmlElement(ElementName = "Location", IsNullable = true, DataType ="string" ), EditorBrowsable(EditorBrowsableState.Advanced)]
		public string Location
		{
			get{return _Location;}
			set{_Location = value;}
		}

	}
}
