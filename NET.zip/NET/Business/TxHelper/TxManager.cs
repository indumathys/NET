using System;
using System.EnterpriseServices;
using System.Runtime.InteropServices;
using MyTelco.Data.hrDAC;
using MyTelco.Business.hrDTO;


namespace MyTelco.Business.TxHelper
{
	/// <summary>
	/// Summary description for TxManager.
	/// </summary>
	[Transaction(TransactionOption.Required)]
	public class TxManager
	{

		/// <summary>
		///  constructor
		/// </summary>
		public TxManager()
		{
		}

		/// <summary>
		///  Transaction to update employee details
		///  Three tables are being updated: emp, emp_photo and emp_resume
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void UpdateEmployeeDetails(EmployeeDTO employeeDTO)
		{

			//declare
			EmployeeDAC employeeDAC;

			try 
			{
				//object creation
				employeeDAC = new EmployeeDAC();

				//Update employee details
				employeeDAC.UpdateEmployeeDetails(employeeDTO); 

				//Update employee Photo
				employeeDAC.UpdateEmployeePhoto(employeeDTO); 

				//Update employee Resume
				employeeDAC.UpdateEmployeeResume(employeeDTO); 

				//commit transation
				ContextUtil.SetComplete();
			}
			catch(Exception ex)
			{
				//Rollback the transaction and throww exception
				ContextUtil.SetAbort();
				throw ex;
			}

		}

		/// <summary>
		///  Transaction to Add new employee 
		///  Three tables are being updated: emp, emp_photo and emp_resume
		/// </summary>
		/// <param name="employeeDTO"></param>
		public void AddNewEmployee(EmployeeDTO employeeDTO)
		{

			//declare
			EmployeeDAC employeeDAC;

			try 
			{
				//object creation
				employeeDAC = new EmployeeDAC();

				//add employee details
				employeeDAC.AddNewEmployee(employeeDTO); 

				//add employee Photo
				employeeDAC.AddNewEmployeePhoto(employeeDTO); 

				//add employee Resume
				employeeDAC.AddNewEmployeeResume(employeeDTO); 

				//commit transation
				ContextUtil.SetComplete();
			}
			catch(Exception ex)
			{
				//Rollback the transaction and throww exception
				ContextUtil.SetAbort();
				throw ex;
			}
		}
        public void EmptyCatchWithExKO()
        {
            try
            {
                //This method does nothing but is added for empty catch block
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public void EmptyCatchWithExOK()
        {
            try
            {
                //This method does nothing but is added for empty catch block
            }
            catch (Exception ex)
            {
                //throw;
            }
        }

	}
}
